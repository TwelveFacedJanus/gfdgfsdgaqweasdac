'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

interface UserProfileViewProps {
  userId: string;
  currentUserId?: string;
}

export default function UserProfileView({ userId, currentUserId }: UserProfileViewProps) {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [stats, setStats] = useState({ posts: 0, subscribers: 0, subscriptions: 0 });

  const isOwnProfile = currentUserId === userId;

  useEffect(() => {
    loadUserProfile();
    if (!isOwnProfile) {
      checkSubscriptionStatus();
    }
  }, [userId]);

  const loadUserProfile = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/api/user/profile/${userId}/`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('access_token')}`,
        },
      });

      if (!response.ok) {
        throw new Error('Не удалось загрузить профиль');
      }

      const data = await response.json();
      setUser(data);
      
      // Загружаем статистику
      loadStats(data);
    } catch (error: any) {
      console.error('Error loading user profile:', error);
      setError(error.message || 'Ошибка при загрузке профиля');
    } finally {
      setIsLoading(false);
    }
  };

  const loadStats = (userData: any) => {
    // Здесь можно загрузить реальную статистику через API
    // Пока используем данные из профиля
    setStats({
      posts: userData.posts_count || 0,
      subscribers: userData.subscribers_count || 0,
      subscriptions: userData.subscriptions_count || 0,
    });
  };

  const checkSubscriptionStatus = async () => {
    try {
      const response = await fetch(
        `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/user-favourites/status/${userId}/`,
        {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('access_token')}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        setIsSubscribed(data.is_subscribed);
      }
    } catch (error) {
      console.error('Error checking subscription status:', error);
    }
  };

  const handleSubscribe = async () => {
    if (isSubscribing) return;

    setIsSubscribing(true);
    try {
      const endpoint = isSubscribed
        ? `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/user-favourites/unsubscribe/${userId}/`
        : `${process.env.NEXT_PUBLIC_API_BASE_URL}/api/user-favourites/subscribe/`;

      const response = await fetch(endpoint, {
        method: isSubscribed ? 'DELETE' : 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('access_token')}`,
          'Content-Type': 'application/json',
        },
        body: isSubscribed ? undefined : JSON.stringify({ subscribed_to: userId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Ошибка при изменении подписки');
      }

      setIsSubscribed(!isSubscribed);
      
      // Обновляем счетчик подписчиков
      setStats(prev => ({
        ...prev,
        subscribers: isSubscribed ? prev.subscribers - 1 : prev.subscribers + 1,
      }));
    } catch (error: any) {
      console.error('Error toggling subscription:', error);
      alert(error.message || 'Ошибка при изменении подписки');
    } finally {
      setIsSubscribing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="text-white text-lg">Зареждане на профил...</div>
      </div>
    );
  }

  if (error || !user) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-[#1A1826] rounded-lg border p-6" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
          <div className="text-center">
            <div className="text-red-400 text-lg mb-4">{error || 'Потребителят не е намерен'}</div>
            <button
              onClick={() => router.back()}
              className="px-6 py-2 bg-[#8A63D2] text-white rounded-lg hover:bg-[#7A53C2] transition-colors"
            >
              Назад
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Шапка профиля */}
      <div className="bg-[#1A1826] rounded-lg border p-6 sm:p-8 mb-6" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
          {/* Аватар */}
          <div className="flex-shrink-0">
            {user.base64_image ? (
              <img
                src={user.base64_image}
                alt={user.fio}
                className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover border-4"
                style={{ borderColor: '#8A63D2' }}
              />
            ) : (
              <div
                className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-gray-600 flex items-center justify-center border-4"
                style={{ borderColor: '#8A63D2' }}
              >
                <svg className="w-12 h-12 sm:w-16 sm:h-16 text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
              </div>
            )}
          </div>

          {/* Информация */}
          <div className="flex-1 min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
              <div>
                <h1 className="text-white text-2xl sm:text-3xl font-bold mb-1">{user.fio}</h1>
                {user.nickname && (
                  <p className="text-gray-400 text-sm sm:text-base">@{user.nickname}</p>
                )}
              </div>

              {/* Кнопка подписки */}
              {!isOwnProfile && (
                <button
                  onClick={handleSubscribe}
                  disabled={isSubscribing}
                  className={`px-6 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                    isSubscribed
                      ? 'bg-gray-600 text-white hover:bg-gray-700'
                      : 'bg-[#8A63D2] text-white hover:bg-[#7A53C2]'
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {isSubscribing ? 'Зареждане...' : isSubscribed ? 'Отпиши се' : 'Абонирай се'}
                </button>
              )}

              {isOwnProfile && (
                <button
                  onClick={() => router.push('/profile')}
                  className="px-6 py-2 bg-[#8A63D2] text-white rounded-lg hover:bg-[#7A53C2] transition-colors whitespace-nowrap"
                >
                  Редактирай профил
                </button>
              )}
            </div>

            {/* Статистика */}
            <div className="flex flex-wrap gap-6 mb-4">
              <div>
                <div className="text-white text-xl font-bold">{stats.posts}</div>
                <div className="text-gray-400 text-sm">Публикации</div>
              </div>
              <div>
                <div className="text-white text-xl font-bold">{stats.subscribers}</div>
                <div className="text-gray-400 text-sm">Абонати</div>
              </div>
              <div>
                <div className="text-white text-xl font-bold">{stats.subscriptions}</div>
                <div className="text-gray-400 text-sm">Абонаменти</div>
              </div>
              {user.rating !== undefined && (
                <div>
                  <div className="text-white text-xl font-bold flex items-center gap-1">
                    <span>⭐</span>
                    <span>{user.rating.toFixed(1)}</span>
                  </div>
                  <div className="text-gray-400 text-sm">Рейтинг</div>
                </div>
              )}
            </div>

            {/* Описание */}
            {user.description && (
              <p className="text-gray-300 text-sm sm:text-base">{user.description}</p>
            )}
          </div>
        </div>

        {/* Социальные сети */}
        {(user.social_vk || user.social_telegram || user.social_instagram || user.social_website) && (
          <div className="mt-6 pt-6 border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
            <div className="flex flex-wrap gap-3">
              {user.social_vk && (
                <a
                  href={user.social_vk}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-[#0077FF] text-white rounded-lg hover:opacity-80 transition-opacity text-sm"
                >
                  VK
                </a>
              )}
              {user.social_telegram && (
                <a
                  href={user.social_telegram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-[#0088CC] text-white rounded-lg hover:opacity-80 transition-opacity text-sm"
                >
                  Telegram
                </a>
              )}
              {user.social_instagram && (
                <a
                  href={user.social_instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg hover:opacity-80 transition-opacity text-sm"
                >
                  Instagram
                </a>
              )}
              {user.social_website && (
                <a
                  href={user.social_website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:opacity-80 transition-opacity text-sm"
                >
                  Веб-сайт
                </a>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Посты пользователя */}
      <div className="bg-[#1A1826] rounded-lg border p-6 sm:p-8" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
        <h2 className="text-white text-xl font-bold mb-4">Публикации на автора</h2>
        <div className="text-gray-400 text-center py-8">
          Тук ще се показват публикациите на потребителя
        </div>
      </div>
    </div>
  );
}
