'use client';

import React, { useState, useRef, useEffect } from 'react';

interface MediaPlayerProps {
  src: string;
  type: 'image' | 'video' | 'audio';
  title?: string;
  alt?: string;
}

export default function MediaPlayer({ src, type, title, alt }: MediaPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const mediaRef = type === 'video' ? videoRef : type === 'audio' ? audioRef : null;

  useEffect(() => {
    if (!mediaRef?.current) return;

    const media = mediaRef.current;

    const handleLoadedMetadata = () => {
      setDuration(media.duration);
      setIsLoading(false);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(media.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
    };

    const handleError = () => {
      console.error(`MediaPlayer error for src: ${src}`, media.error);
      setIsLoading(false);
    };

    media.addEventListener('loadedmetadata', handleLoadedMetadata);
    media.addEventListener('timeupdate', handleTimeUpdate);
    media.addEventListener('ended', handleEnded);
    media.addEventListener('error', handleError);

    return () => {
      media.removeEventListener('loadedmetadata', handleLoadedMetadata);
      media.removeEventListener('timeupdate', handleTimeUpdate);
      media.removeEventListener('ended', handleEnded);
      media.removeEventListener('error', handleError);
    };
  }, [mediaRef, src]);

  const togglePlayPause = () => {
    if (!mediaRef?.current) return;
    if (isPlaying) {
      mediaRef.current.pause();
    } else {
      mediaRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleProgressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!mediaRef?.current) return;
    const newTime = parseFloat(e.target.value);
    mediaRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (mediaRef?.current) {
      mediaRef.current.volume = newVolume;
    }
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;

    try {
      if (!isFullscreen) {
        await containerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch (error) {
      console.error('Fullscreen error:', error);
    }
  };

  const formatTime = (time: number): string => {
    if (!isFinite(time)) return '00:00';
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  if (type === 'image') {
    return (
      <div className="w-full rounded-lg overflow-hidden bg-black">
        <img
          src={src}
          alt={alt || 'Изображение'}
          className="w-full h-auto object-contain"
          crossOrigin="anonymous"
        />
      </div>
    );
  }

  if (type === 'video') {
    return (
      <div
        ref={containerRef}
        className="w-full bg-black rounded-lg overflow-hidden group/video"
      >
        <div className="relative bg-black aspect-video flex items-center justify-center">
          <video
            ref={videoRef}
            src={src}
            className="w-full h-full object-contain"
            crossOrigin="anonymous"
            preload="metadata"
            onMouseEnter={() => {}}
            onMouseLeave={() => {}}
          />

          {/* Загрузка */}
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
              <svg
                className="animate-spin h-12 w-12 text-white"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
              >
                <circle
                  className="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  strokeWidth="4"
                />
                <path
                  className="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
            </div>
          )}

          {/* Play кнопка посередине */}
          <button
            onClick={togglePlayPause}
            className="absolute inset-0 flex items-center justify-center group/play hover:bg-black hover:bg-opacity-30 transition-all"
          >
            <div className="w-16 h-16 rounded-full bg-white bg-opacity-80 group-hover/play:bg-opacity-100 flex items-center justify-center transition-all transform group-hover/play:scale-110">
              {isPlaying ? (
                <svg
                  className="w-8 h-8 text-black ml-0.5"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
                </svg>
              ) : (
                <svg
                  className="w-8 h-8 text-black ml-1"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M8 5v14l11-7z" />
                </svg>
              )}
            </div>
          </button>

          {/* Контролы внизу */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black to-transparent p-4 translate-y-full group-hover/video:translate-y-0 transition-transform duration-200">
            {/* Прогресс бар */}
            <input
              type="range"
              min="0"
              max={duration || 0}
              value={currentTime}
              onChange={handleProgressChange}
              className="w-full h-1 bg-gray-600 rounded appearance-none cursor-pointer accent-cyan-400 hover:h-2 transition-all"
              style={{
                background: `linear-gradient(to right, rgb(34 197 94) 0%, rgb(34 197 94) ${
                  duration ? (currentTime / duration) * 100 : 0
                }%, rgb(75 85 99) ${duration ? (currentTime / duration) * 100 : 0}%, rgb(75 85 99) 100%)`,
              }}
            />

            {/* Контролы */}
            <div className="flex items-center justify-between mt-3">
              <div className="flex items-center gap-2">
                {/* Play/Pause */}
                <button
                  onClick={togglePlayPause}
                  className="hover:text-cyan-400 transition-colors text-white"
                  title={isPlaying ? 'Пауза' : 'Воспроизведение'}
                >
                  {isPlaying ? (
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
                    </svg>
                  ) : (
                    <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M8 5v14l11-7z" />
                    </svg>
                  )}
                </button>

                {/* Volume */}
                <div className="flex items-center gap-2 group/volume">
                  <button className="hover:text-cyan-400 transition-colors text-white">
                    {volume === 0 ? (
                      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M16.5 12c0-1.77-1.02-3.3-2.5-4.06v2.58l2.24 2.24c.09-.38.26-.74.26-1.76zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C23.16 14.18 24 11.25 24 8c0-4.97-4.03-9-9-9-3.25 0-6.18.84-8.15 2.31l1.51 1.51c.82-.34 1.7-.54 2.64-.54v3zm-9-9C6.48 3 3.81 5.65 3.81 9c0 .95.19 1.86.52 2.69L2.31 14.9C.84 12.93 0 10.25 0 8c0-4.97 4.03-9 9-9 2.25 0 4.33.84 6.07 2.28l-1.51 1.51C13.28 3.51 11.25 3 9 3z" />
                      </svg>
                    ) : (
                      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.3-2.5-4.06v8.12c1.48-.76 2.5-2.29 2.5-4.06zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
                      </svg>
                    )}
                  </button>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={volume}
                    onChange={handleVolumeChange}
                    className="w-0 group-hover/volume:w-24 transition-all h-1 bg-gray-600 rounded appearance-none cursor-pointer accent-cyan-400"
                  />
                </div>

                {/* Время */}
                <span className="text-white text-sm ml-2">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              </div>

              {/* Полноэкран */}
              <button
                onClick={toggleFullscreen}
                className="hover:text-cyan-400 transition-colors text-white"
                title="Полноэкран"
              >
                {isFullscreen ? (
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z" />
                  </svg>
                ) : (
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (type === 'audio') {
    return (
      <div className="w-full bg-gradient-to-r from-purple-900 to-purple-800 rounded-lg p-6">
        <audio
          ref={audioRef}
          src={src}
          crossOrigin="anonymous"
          preload="metadata"
        />

        {isLoading ? (
          <div className="flex items-center justify-center gap-3 py-4">
            <svg
              className="animate-spin h-6 w-6 text-white"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              />
            </svg>
            <span className="text-white">Загрузка аудио...</span>
          </div>
        ) : (
          <div className="flex items-center gap-4">
            {/* Play Button */}
            <button
              onClick={togglePlayPause}
              disabled={!duration}
              className="flex-shrink-0 w-12 h-12 rounded-full bg-white bg-opacity-20 hover:bg-opacity-30 transition-all flex items-center justify-center text-white hover:text-cyan-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isPlaying ? (
                <svg className="w-6 h-6 ml-0" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
                </svg>
              ) : (
                <svg className="w-6 h-6 ml-1" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z" />
                </svg>
              )}
            </button>

            {/* Информация */}
            <div className="flex-1">
              <div className="mb-2">
                <h4 className="text-white font-medium">{title || 'Аудиофайл'}</h4>
                <p className="text-gray-300 text-sm">{formatTime(currentTime)} / {formatTime(duration)}</p>
              </div>

            {/* Прогресс бар */}
            <input
              type="range"
              min="0"
              max={duration || 0}
              value={currentTime}
              onChange={handleProgressChange}
              className="w-full h-1 bg-white bg-opacity-20 rounded appearance-none cursor-pointer accent-cyan-400"
              style={{
                background: `linear-gradient(to right, rgb(34 197 94) 0%, rgb(34 197 94) ${
                  duration ? (currentTime / duration) * 100 : 0
                }%, rgba(255 255 255 / 0.2) ${duration ? (currentTime / duration) * 100 : 0}%, rgba(255 255 255 / 0.2) 100%)`,
              }}
            />
          </div>

            {/* Volume */}
            <div className="flex items-center gap-2 group/volume">
              <button className="text-white hover:text-cyan-300 transition-colors">
                {volume === 0 ? (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M16.5 12c0-1.77-1.02-3.3-2.5-4.06v2.58l2.24 2.24c.09-.38.26-.74.26-1.76zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C23.16 14.18 24 11.25 24 8c0-4.97-4.03-9-9-9-3.25 0-6.18.84-8.15 2.31l1.51 1.51c.82-.34 1.7-.54 2.64-.54v3zm-9-9C6.48 3 3.81 5.65 3.81 9c0 .95.19 1.86.52 2.69L2.31 14.9C.84 12.93 0 10.25 0 8c0-4.97 4.03-9 9-9 2.25 0 4.33.84 6.07 2.28l-1.51 1.51C13.28 3.51 11.25 3 9 3z" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.3-2.5-4.06v8.12c1.48-.76 2.5-2.29 2.5-4.06zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" />
                  </svg>
                )}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={volume}
                onChange={handleVolumeChange}
                className="w-0 group-hover/volume:w-16 transition-all h-1 bg-white bg-opacity-20 rounded appearance-none cursor-pointer accent-cyan-400"
              />
            </div>
          </div>
        )}
      </div>
    );
  }

  return null;
}
