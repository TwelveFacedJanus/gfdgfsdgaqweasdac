'use client';

import { useState, useEffect } from 'react';
import { getCategories, type Category } from '@/lib/api';

interface LeftSidebarProps {
  activeCategory?: string;
  onCategoryChange?: (category: string) => void;
}

export default function LeftSidebar({ activeCategory = 'all', onCategoryChange }: LeftSidebarProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const categoriesData = await getCategories();
        // Добавляем категорию "Все" в начало
        const allCategories = [
          { 
            id: 'all', 
            name: 'Все', 
            slug: 'all', 
            description: 'Все категории', 
            icon: '📚', 
            order: 0, 
            is_active: true, 
            posts_count: 0 
          },
          ...categoriesData
        ];
        setCategories(allCategories);
      } catch (error) {
        console.error('Error loading categories:', error);
        // Fallback к статичным категориям
        setCategories([
          { id: 'all', name: 'Все', slug: 'all', description: '', icon: '📚', order: 0, is_active: true, posts_count: 0 },
          { id: 'esoterics', name: 'Эзотерика', slug: 'esoterics', description: '', icon: '🔮', order: 1, is_active: true, posts_count: 0 },
          { id: 'astrology', name: 'Астрология', slug: 'astrology', description: '', icon: '⭐', order: 2, is_active: true, posts_count: 0 },
          { id: 'tarot', name: 'Таро', slug: 'tarot', description: '', icon: '🃏', order: 3, is_active: true, posts_count: 0 },
          { id: 'numerology', name: 'Нумерология', slug: 'numerology', description: '', icon: '🔢', order: 4, is_active: true, posts_count: 0 },
          { id: 'meditation', name: 'Медитация', slug: 'meditation', description: '', icon: '🧘', order: 5, is_active: true, posts_count: 0 },
          { id: 'spirituality', name: 'Духовность', slug: 'spirituality', description: '', icon: '✨', order: 6, is_active: true, posts_count: 0 },
          { id: 'other', name: 'Другое', slug: 'other', description: '', icon: '📝', order: 7, is_active: true, posts_count: 0 },
        ]);
      } finally {
        setIsLoading(false);
      }
    };

    loadCategories();
  }, []);

  const handleCategoryClick = (categoryId: string) => {
    if (onCategoryChange) {
      onCategoryChange(categoryId);
    }
  };

  if (isLoading) {
    return (
      <div 
        className="bg-[#1A1826] rounded-2xl sm:rounded-[32px] p-4 sm:p-6 h-fit border w-full lg:w-[277px]"
        style={{ 
          borderWidth: '1px',
          borderColor: 'rgba(255, 255, 255, 0.1)',
          boxShadow: '0px 0px 120px 0px rgba(255, 255, 255, 0.1)'
        }}
      >
        <div className="space-y-[10px]">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="flex items-center space-x-3 px-3 py-2 rounded-lg">
              <div className="w-2 h-2 bg-gray-600 rounded-full animate-pulse"></div>
              <div className="w-20 h-4 bg-gray-600 rounded animate-pulse"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div 
      className="bg-[#00051B] rounded-2xl sm:rounded-[32px] p-4 sm:p-6 h-fit border w-full lg:w-[277px]"
      style={{ 
        borderWidth: '1px',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        boxShadow: '0px 0px 120px 0px rgba(255, 255, 255, 0.1)'
      }}
    >
      <nav className="space-y-[10px]">
        {categories.map((category, index) => (
          <button
            key={category.id}
            onClick={() => handleCategoryClick(category.slug)}
            className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 text-left ${
              activeCategory === category.slug
                ? 'bg-[#333333] text-white scale-105'
                : 'text-gray-300 hover:text-white hover:bg-[#2A2A2A] hover:scale-105'
            }`}
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <span className="text-base">{category.icon}</span>
            <span className="text-sm font-medium">{category.name}</span>
            {category.posts_count > 0 && (
              <span className="ml-auto text-xs text-white/50">
                {category.posts_count}
              </span>
            )}
          </button>
        ))}
      </nav>
    </div>
  );
}
