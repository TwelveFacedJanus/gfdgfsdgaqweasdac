'use client';

/**
 * Демонстрационный компонент MediaPlayer
 * Показывает все возможности плеера
 */

import React from 'react';
import MediaPlayer from '@/components/MediaPlayer';

export default function MediaPlayerDemo() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Заголовок */}
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold text-white mb-4">🎬 MediaPlayer Демонстрация</h1>
          <p className="text-gray-300 text-lg">Универсальный плеер для видео, аудио и изображений</p>
        </div>

        {/* Галерея примеров */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Раздел 1: Изображения */}
          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <span>📸</span> Изображения
            </h2>
            <p className="text-gray-400 text-sm mb-4">Отображение изображений в адаптивном контейнере</p>
            <div className="space-y-4">
              {/* Пример изображения */}
              <div className="bg-slate-900 rounded p-4">
                <p className="text-gray-400 text-xs mb-2">Пример PNG:</p>
                <MediaPlayer 
                  src="https://images.unsplash.com/photo-1611339555312-e607c04352fa?w=800"
                  type="image"
                  alt="Пример изображения"
                />
              </div>
              <code className="text-xs text-purple-300 bg-slate-900 p-3 rounded block overflow-auto">
{`<MediaPlayer 
  src="/image.jpg"
  type="image"
  alt="Описание"
/>`}
              </code>
            </div>
          </div>

          {/* Раздел 2: Видео */}
          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <span>🎥</span> Видео
            </h2>
            <p className="text-gray-400 text-sm mb-4">Видеоплеер с полным управлением</p>
            <div className="space-y-4">
              {/* Пример видео - используем placeholder */}
              <div className="bg-slate-900 rounded p-4">
                <p className="text-gray-400 text-xs mb-2">Функциональность:</p>
                <ul className="text-gray-300 text-sm space-y-1 ml-4">
                  <li>✅ Play/Pause кнопка</li>
                  <li>✅ Прогресс-бар</li>
                  <li>✅ Громкость</li>
                  <li>✅ Полноэкран</li>
                  <li>✅ Время отображение</li>
                </ul>
              </div>
              <code className="text-xs text-purple-300 bg-slate-900 p-3 rounded block overflow-auto">
{`<MediaPlayer 
  src="/video.mp4"
  type="video"
/>`}
              </code>
            </div>
          </div>

          {/* Раздел 3: Аудио */}
          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700 lg:col-span-2">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <span>🎵</span> Аудио
            </h2>
            <p className="text-gray-400 text-sm mb-4">Аудиоплеер с минималистичным дизайном</p>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Демо аудиоплеер */}
              <div className="bg-slate-900 rounded p-4">
                <p className="text-gray-400 text-xs mb-3">Пример аудиоплеера:</p>
                <MediaPlayer 
                  src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
                  type="audio"
                  title="Демонстрационный трек"
                />
              </div>
              {/* Характеристики */}
              <div className="bg-slate-900 rounded p-4">
                <p className="text-gray-400 text-xs mb-2">Особенности:</p>
                <ul className="text-gray-300 text-sm space-y-1">
                  <li>✅ Фиолетовый градиент</li>
                  <li>✅ Прогресс-бар</li>
                  <li>✅ Громкость (hover)</li>
                  <li>✅ Время трека</li>
                  <li>✅ Название файла</li>
                </ul>
              </div>
            </div>
            <code className="text-xs text-purple-300 bg-slate-900 p-3 rounded block overflow-auto mt-4">
{`<MediaPlayer 
  src="/audio.mp3"
  type="audio"
  title="Название трека"
/>`}
            </code>
          </div>
        </div>

        {/* Таблица Props */}
        <div className="mt-12 bg-slate-800 rounded-lg p-6 border border-slate-700">
          <h2 className="text-2xl font-bold text-white mb-4">📋 Props</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-gray-300">
              <thead>
                <tr className="border-b border-slate-600">
                  <th className="text-left py-3 px-4 font-semibold text-white">Prop</th>
                  <th className="text-left py-3 px-4 font-semibold text-white">Type</th>
                  <th className="text-left py-3 px-4 font-semibold text-white">Обязательно</th>
                  <th className="text-left py-3 px-4 font-semibold text-white">Описание</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-700 hover:bg-slate-700/50">
                  <td className="py-3 px-4 font-mono text-purple-300">src</td>
                  <td className="py-3 px-4 font-mono text-cyan-300">string</td>
                  <td className="py-3 px-4">✅ Да</td>
                  <td className="py-3 px-4">URL медиафайла</td>
                </tr>
                <tr className="border-b border-slate-700 hover:bg-slate-700/50">
                  <td className="py-3 px-4 font-mono text-purple-300">type</td>
                  <td className="py-3 px-4 font-mono text-cyan-300">image | video | audio</td>
                  <td className="py-3 px-4">✅ Да</td>
                  <td className="py-3 px-4">Тип медиа</td>
                </tr>
                <tr className="border-b border-slate-700 hover:bg-slate-700/50">
                  <td className="py-3 px-4 font-mono text-purple-300">title</td>
                  <td className="py-3 px-4 font-mono text-cyan-300">string</td>
                  <td className="py-3 px-4">❌ Нет</td>
                  <td className="py-3 px-4">Заголовок (для аудио)</td>
                </tr>
                <tr className="hover:bg-slate-700/50">
                  <td className="py-3 px-4 font-mono text-purple-300">alt</td>
                  <td className="py-3 px-4 font-mono text-cyan-300">string</td>
                  <td className="py-3 px-4">❌ Нет</td>
                  <td className="py-3 px-4">Alt текст (для изображений)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Горячие клавиши */}
        <div className="mt-8 bg-slate-800 rounded-lg p-6 border border-slate-700">
          <h2 className="text-2xl font-bold text-white mb-4">⌨️ Горячие клавиши (Видео)</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-900 rounded p-4">
              <p className="text-purple-300 font-mono mb-2">Space</p>
              <p className="text-gray-400">Play / Pause</p>
            </div>
            <div className="bg-slate-900 rounded p-4">
              <p className="text-purple-300 font-mono mb-2">F</p>
              <p className="text-gray-400">Полноэкран</p>
            </div>
            <div className="bg-slate-900 rounded p-4">
              <p className="text-purple-300 font-mono mb-2">M</p>
              <p className="text-gray-400">Вкл/Выкл звук</p>
            </div>
            <div className="bg-slate-900 rounded p-4">
              <p className="text-purple-300 font-mono mb-2">← →</p>
              <p className="text-gray-400">Перемотка (-5 / +5 сек)</p>
            </div>
          </div>
        </div>

        {/* Поддерживаемые форматы */}
        <div className="mt-8 bg-slate-800 rounded-lg p-6 border border-slate-700">
          <h2 className="text-2xl font-bold text-white mb-4">📦 Поддерживаемые форматы</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-purple-300 mb-3">🎥 Видео</h3>
              <ul className="text-gray-300 space-y-1">
                <li>• MP4 (video/mp4)</li>
                <li>• WebM (video/webm)</li>
                <li>• Ogg (video/ogg)</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-purple-300 mb-3">🎵 Аудио</h3>
              <ul className="text-gray-300 space-y-1">
                <li>• MP3 (audio/mpeg)</li>
                <li>• WAV (audio/wav)</li>
                <li>• Ogg (audio/ogg)</li>
                <li>• WebM (audio/webm)</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-purple-300 mb-3">📸 Изображения</h3>
              <ul className="text-gray-300 space-y-1">
                <li>• JPEG/JPG</li>
                <li>• PNG</li>
                <li>• WebP</li>
                <li>• GIF</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-gray-500 text-sm">
          <p>MediaPlayer v1.0 • Создан для отображения медиа-контента в постах</p>
        </div>
      </div>
    </div>
  );
}
