// Утилита для установки заголовка страницы
export const setPageTitle = (title: string) => {
  if (typeof document !== 'undefined') {
    document.title = `${title} | Ezoterika`;
  }
};
