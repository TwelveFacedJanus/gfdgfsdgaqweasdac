'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getStoredTokens } from '@/lib/api';
import { setPageTitle } from '@/lib/setPageTitle';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function ContactPage() {
  const router = useRouter();

  useEffect(() => {
    setPageTitle('Контакти');
    const { accessToken } = getStoredTokens();
    if (!accessToken) {
      router.push('/signIn');
      return;
    }
  }, [router]);

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#090F1B' }}>
      <Header activePage="" />
      
      <main className="flex-1 max-w-[1920px] w-full mx-auto px-4 sm:px-6 lg:px-[50px] py-6 sm:py-8 lg:py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-white text-2xl sm:text-3xl lg:text-4xl font-bold mb-6 sm:mb-8">
            Контакти
          </h1>

          <div className="bg-[#1A1826] rounded-lg border p-6 sm:p-8" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
            <div className="text-gray-300 space-y-6">
              <section>
                <h2 className="text-white text-xl font-semibold mb-3">Свържете се с нас</h2>
                <p className="mb-4">
                  Винаги сме готови да отговорим на вашите въпроси и предложения. 
                  Изберете удобен начин за връзка:
                </p>
              </section>

              <section>
                <h3 className="text-white text-lg font-semibold mb-3">Имейл</h3>
                <p>
                  Общи въпроси: <a href="mailto:support@ezoterika.com" className="text-[#8A63D2] hover:text-[#7A53C2] transition-colors">support@ezoterika.com</a>
                </p>
                <p>
                  Техническа поддръжка: <a href="mailto:tech@ezoterika.com" className="text-[#8A63D2] hover:text-[#7A53C2] transition-colors">tech@ezoterika.com</a>
                </p>
                <p>
                  Сътрудничество: <a href="mailto:partnership@ezoterika.com" className="text-[#8A63D2] hover:text-[#7A53C2] transition-colors">partnership@ezoterika.com</a>
                </p>
              </section>

              <section>
                <h3 className="text-white text-lg font-semibold mb-3">Работно време</h3>
                <p>
                  Отговаряме на запитвания в работни дни от 10:00 до 19:00 (МСК).
                  Обикновено отговаряме в рамките на 24 часа.
                </p>
              </section>

              <section>
                <h3 className="text-white text-lg font-semibold mb-3">Социални мрежи</h3>
                <div className="flex flex-wrap gap-4">
                  <a 
                    href="#" 
                    className="flex items-center gap-2 px-4 py-2 bg-[#0088CC] rounded-lg text-white hover:opacity-80 transition-opacity"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
                    </svg>
                    Telegram
                  </a>
                  
                  <a 
                    href="#" 
                    className="flex items-center gap-2 px-4 py-2 bg-[#0077FF] rounded-lg text-white hover:opacity-80 transition-opacity"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.14C2 20.67 3.33 22 8.93 22h6.14c5.6 0 6.93-1.33 6.93-6.93V8.93C22 3.33 20.67 2 15.07 2zm3.45 14.41h-1.31c-.57 0-.74-.46-1.76-1.48-.89-.89-1.28-1.01-1.5-1.01-.31 0-.4.09-.4.52v1.35c0 .36-.12.58-1.06.58-1.56 0-3.29-.94-4.51-2.7-1.84-2.62-2.34-4.58-2.34-4.98 0-.22.09-.43.52-.43h1.31c.39 0 .54.18.69.6.74 2.14 1.98 4.01 2.49 4.01.19 0 .28-.09.28-.58v-2.25c-.06-.99-.58-1.08-.58-1.43 0-.18.15-.36.39-.36h2.06c.33 0 .45.18.45.57v3.04c0 .33.15.45.24.45.19 0 .35-.12.7-.47 1.08-1.21 1.85-3.08 1.85-3.08.1-.21.28-.43.72-.43h1.31c.47 0 .57.24.47.57-.15.81-1.91 3.47-1.91 3.47-.16.26-.22.37 0 .66.16.21.69.68 1.05 1.08.65.75 1.15 1.38 1.28 1.81.14.43-.07.65-.5.65z"/>
                    </svg>
                    VK
                  </a>
                </div>
              </section>

              <section className="pt-6 border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
                <p className="text-gray-400 text-sm">
                  Ценим всяко запитване и се стараем да помогнем на всички наши потребители. 
                  Благодарим ви, че избрахте Ezoterika!
                </p>
              </section>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
