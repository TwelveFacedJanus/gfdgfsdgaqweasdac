'use client';

import { Suspense, useState, useEffect } from 'react';
import { useRouter, useParams, useSearchParams } from 'next/navigation';
import { getStoredTokens, setStoredTokens, getPostDetail, updateContent, uploadPostFile, getCategories, type Category } from '@/lib/api';
import { setPageTitle } from '@/lib/setPageTitle';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import RichTextEditor from '@/components/RichTextEditor';

interface ContentBlock {
  id: string;
  isHeader?: boolean; // Первый блок - заголовок и обложка
  title?: string;
  description?: string;
  coverImage?: string; // Только для header блока
  audioFiles?: File[];
  videoFiles?: File[];
  imageFiles?: File[];
}

export default function EditContentPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-white">Загрузка...</div>}>
      <EditContentPageContent />
    </Suspense>
  );
}
export const dynamic = 'force-dynamic';

function EditContentPageContent() {
  const router = useRouter();
  const params = useParams();
  const searchParams = useSearchParams();
  const postId = params.id as string;
  
  const [blocks, setBlocks] = useState<ContentBlock[]>([
    {
      id: 'header-block',
      isHeader: true,
      title: '',
      description: '',
      coverImage: '',
    }
  ]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [isPublished, setIsPublished] = useState(true);
  const [accessibility, setAccessibility] = useState<'subscribers' | 'all' | 'my_subscribers'>('all');
  
  // Планировщик
  const [scheduledPublish, setScheduledPublish] = useState(false);
  const [publishDate, setPublishDate] = useState('');
  const [publishTime, setPublishTime] = useState('');
  
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [dragOverCover, setDragOverCover] = useState(false);

  // Авторизация
  useEffect(() => {
    setPageTitle('Редактировать пост');
    const token = searchParams.get('token');
    const refreshToken = searchParams.get('refresh_token');
    if (token && refreshToken) {
      setStoredTokens(token, refreshToken);
      window.history.replaceState({}, '', window.location.pathname);
      window.location.reload();
    } else {
      const { accessToken } = getStoredTokens();
      if (!accessToken) router.push('/signIn');
    }
  }, [searchParams, router]);

  // Загрузка категорий
  useEffect(() => {
    const loadCategories = async () => {
      try {
        const categoriesData = await getCategories();
        setCategories(categoriesData);
        // Устанавливаем первую категорию по умолчанию если не выбрана
        if (categoriesData.length > 0 && !selectedCategory) {
          setSelectedCategory(categoriesData[0].id);
        }
      } catch (error) {
        console.error('Error loading categories:', error);
      }
    };
    loadCategories();
  }, []);

  // Загружаем существующие данные
  useEffect(() => {
    if (postId) {
      loadPost();
    }
  }, [postId]);

  const loadPost = async () => {
    try {
      setIsLoading(true);
      const response = await getPostDetail(postId);
      const postData = response.post || response;
      
      // Создаем header блок с основной информацией
      const headerBlock: ContentBlock = {
        id: 'header-block',
        isHeader: true,
        title: postData.title || '',
        description: postData.preview_text || '',
        coverImage: postData.preview_image_link || '',
      };
      
      setSelectedCategory(postData.category || '');
      setIsPublished(postData.is_published || false);
      setAccessibility(postData.accessibility || 'all');
      
      // Парсим markdown контент в блоки
      const contentBlocks: ContentBlock[] = [];
      if (postData.content) {
        // Разделяем контент по разделителям ---
        const sections = postData.content.split(/\n---\n/);
        
        sections.forEach((section: string, index: number) => {
          const lines = section.trim().split('\n');
          let title = '';
          let description = '';
          
          for (const line of lines) {
            if (line.startsWith('## ')) {
              title = line.replace('## ', '');
            } else if (line.trim() && !line.startsWith('![') && !line.startsWith('[')) {
              description += line + '\n';
            }
          }
          
          if (title || description.trim()) {
            contentBlocks.push({
              id: `block-${index}`,
              isHeader: false,
              title: title,
              description: description.trim(),
              audioFiles: [],
              videoFiles: [],
              imageFiles: [],
            });
          }
        });
      }
      
      // Устанавливаем блоки: header + content blocks
      setBlocks([headerBlock, ...contentBlocks]);
      
    } catch (error) {
      console.error('Error loading post:', error);
      alert('Ошибка загрузки поста');
      router.push('/contents');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const headerBlock = blocks[0];
    const hasContent = !!(headerBlock?.title || headerBlock?.coverImage || blocks.length > 1);
    setHasUnsavedChanges(hasContent);
  }, [blocks]);

  // Предупреждение при попытке покинуть страницу
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  const addBlock = () => {
    const newBlock: ContentBlock = {
      id: Date.now().toString(),
      isHeader: false,
      title: '',
      description: '',
      audioFiles: [],
      videoFiles: [],
      imageFiles: [],
    };
    setBlocks(prev => [...prev, { ...newBlock }]);
  };

  const removeBlock = (id: string) => {
    // Нельзя удалить header блок
    if (id === 'header-block') return;
    setBlocks(prev => prev.filter(b => b.id !== id));
  };

  const moveBlock = (id: string, direction: 'up' | 'down') => {
    // Нельзя перемещать header блок
    if (id === 'header-block') return;
    
    const index = blocks.findIndex(b => b.id === id);
    if (index === -1 || index === 0) return; // index 0 это header
    
    const newBlocks = [...blocks];
    if (direction === 'up' && index > 1) { // Не можем подняться выше header блока
      [newBlocks[index - 1], newBlocks[index]] = [newBlocks[index], newBlocks[index - 1]];
    } else if (direction === 'down' && index < newBlocks.length - 1) {
      [newBlocks[index], newBlocks[index + 1]] = [newBlocks[index + 1], newBlocks[index]];
    }
    setBlocks(newBlocks);
  };

  const updateBlock = (id: string, field: keyof ContentBlock, value: any) => {
    setBlocks(prev => prev.map(b => (b.id === id ? { ...b, [field]: value } : b)));
  };

  // Обложка для header блока
  const handleCoverImageUpload = (file: File) => {
    if (file.size > 3 * 1024 * 1024) {
      alert('Обложка не более 3МБ');
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d')!;
        const maxW = 1200, maxH = 800;
        let w = img.width, h = img.height;
        if (w > maxW || h > maxH) {
          const ratio = Math.min(maxW / w, maxH / h);
          w *= ratio; h *= ratio;
        }
        canvas.width = w; canvas.height = h;
        ctx.drawImage(img, 0, 0, w, h);
        updateBlock('header-block', 'coverImage', canvas.toDataURL('image/jpeg', 0.9));
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleImageFileAdd = (blockId: string, file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      alert('Изображение не должно превышать 5МБ');
      return;
    }
    setBlocks(prev => prev.map(b => {
      if (b.id === blockId) {
        return { ...b, imageFiles: [...(b.imageFiles || []), file] };
      }
      return b;
    }));
  };

  const handleAudioFileAdd = (blockId: string, file: File) => {
    if (file.size > 15 * 1024 * 1024) {
      alert('Аудио файл не должен превышать 15МБ');
      return;
    }
    setBlocks(prev => prev.map(b => {
      if (b.id === blockId) {
        return { ...b, audioFiles: [...(b.audioFiles || []), file] };
      }
      return b;
    }));
  };

  const handleVideoFileAdd = (blockId: string, file: File) => {
    if (file.size > 50 * 1024 * 1024) {
      alert('Видео файл не должен превышать 50МБ');
      return;
    }
    setBlocks(prev => prev.map(b => {
      if (b.id === blockId) {
        return { ...b, videoFiles: [...(b.videoFiles || []), file] };
      }
      return b;
    }));
  };

  const removeMediaFile = (blockId: string, fileIndex: number, type: 'audio' | 'video' | 'image') => {
    setBlocks(prev => prev.map(b => {
      if (b.id === blockId) {
        if (type === 'audio') {
          return { ...b, audioFiles: b.audioFiles?.filter((_, i) => i !== fileIndex) };
        } else if (type === 'video') {
          return { ...b, videoFiles: b.videoFiles?.filter((_, i) => i !== fileIndex) };
        } else {
          return { ...b, imageFiles: b.imageFiles?.filter((_, i) => i !== fileIndex) };
        }
      }
      return b;
    }));
  };

  const handleSave = async () => {
    const headerBlock = blocks[0];
    if (!headerBlock?.title?.trim()) {
      alert('Введите заголовок поста');
      return;
    }

    setIsSaving(true);
    try {
      // Генерируем markdown только из контентных блоков (пропускаем header)
      const contentBlocks = blocks.slice(1);
      const markdownContent = contentBlocks.map(block => {
        let content = '';
        if (block.title) content += `## ${block.title}\n\n`;
        if (block.description) content += `${block.description}\n\n`;
        
        // Добавляем изображения
        if (block.imageFiles?.length) {
          block.imageFiles.forEach(f => {
            content += `![${f.name}](${f.name})\n\n`;
          });
        }
        
        // Добавляем аудио файлы
        if (block.audioFiles?.length) {
          block.audioFiles.forEach(f => {
            content += `[🎵 ${f.name}](${f.name})\n\n`;
          });
        }
        
        // Добавляем видео файлы
        if (block.videoFiles?.length) {
          block.videoFiles.forEach(f => {
            content += `[🎬 ${f.name}](${f.name})\n\n`;
          });
        }
        
        return content;
      }).join('---\n\n');

      // Используем description из header блока как preview_text, или первый description из контента
      const previewText = headerBlock.description?.slice(0, 300) || 
                         contentBlocks.find(b => b.description)?.description?.slice(0, 300) || 
                         headerBlock.title;

      const data: any = {
        title: headerBlock.title.trim(),
        preview_text: previewText.trim(),
        content: markdownContent.trim(),
        preview_image_link: headerBlock.coverImage || null,
        category: selectedCategory,
        is_published: isPublished && !scheduledPublish,
        accessibility,
      };

      if (scheduledPublish && publishDate && publishTime) {
        data.scheduled_publish_at = `${publishDate}T${publishTime}:00`;
      }

      const response = await updateContent(postId, data);

      // Upload files and collect their paths for markdown update
      const filePathMap: Record<string, string> = {};
      
      // Upload image, audio and video files
      for (const block of blocks) {
        // Upload image files
        if (block.imageFiles) {
          for (const file of block.imageFiles) {
            try {
              const uploadResponse = await uploadPostFile(postId, file);
              // Store the mapping of filename to actual file path
              if (uploadResponse.file && uploadResponse.file.file) {
                filePathMap[file.name] = uploadResponse.file.file;
              }
            } catch (err: any) {
              console.error(`Failed to upload image file ${file.name}:`, err);
            }
          }
        }
        
        // Upload audio files
        if (block.audioFiles) {
          for (const file of block.audioFiles) {
            try {
              const uploadResponse = await uploadPostFile(postId, file);
              if (uploadResponse.file && uploadResponse.file.file) {
                filePathMap[file.name] = uploadResponse.file.file;
              }
            } catch (err: any) {
              console.error(`Failed to upload audio file ${file.name}:`, err);
            }
          }
        }
        
        // Upload video files
        if (block.videoFiles) {
          for (const file of block.videoFiles) {
            try {
              const uploadResponse = await uploadPostFile(postId, file);
              if (uploadResponse.file && uploadResponse.file.file) {
                filePathMap[file.name] = uploadResponse.file.file;
              }
            } catch (err: any) {
              console.error(`Failed to upload video file ${file.name}:`, err);
            }
          }
        }
      }

      // Update markdown content with actual file paths
      if (Object.keys(filePathMap).length > 0) {
        let updatedMarkdown = markdownContent;
        for (const [filename, filepath] of Object.entries(filePathMap)) {
          // Replace all occurrences of the filename with the actual path
          // Handle image markdown: ![filename](filename) -> ![filename](filepath)
          updatedMarkdown = updatedMarkdown.replace(
            new RegExp(`!\\[([^\\]]*)\\]\\(${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\)`, 'g'),
            `![$1](${filepath})`
          );
          // Handle audio markdown: [🎵 filename](filename) -> [🎵 filename](filepath)
          updatedMarkdown = updatedMarkdown.replace(
            new RegExp(`\\[🎵\\s*([^\\]]*)\\]\\(${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\)`, 'g'),
            `[🎵 $1](${filepath})`
          );
          // Handle video markdown: [🎬 filename](filename) -> [🎬 filename](filepath)
          updatedMarkdown = updatedMarkdown.replace(
            new RegExp(`\\[🎬\\s*([^\\]]*)\\]\\(${filename.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\)`, 'g'),
            `[🎬 $1](${filepath})`
          );
        }
        
        // Update the post with corrected markdown
        try {
          await updateContent(postId, { content: updatedMarkdown });
        } catch (err: any) {
          console.error('Failed to update post content with file paths:', err);
        }
      }

      setHasUnsavedChanges(false);
      alert(scheduledPublish ? 'Пост запланирован!' : 'Пост обновлен!');
      router.push('/contents');
    } catch (err: any) {
      alert(err.message || 'Ошибка сохранения');
    } finally {
      setIsSaving(false);
    }
  };

  // Обработка drop для обложки
  const handleCoverDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOverCover(false);

    const files = Array.from(e.dataTransfer.files);
    const imageFile = files.find(file => file.type.startsWith('image/'));
    if (imageFile) {
      handleCoverImageUpload(imageFile);
    }
  };

  // Глобальный обработчик для сброса состояния при выходе за пределы страницы
  useEffect(() => {
    const handleGlobalDragLeave = (e: DragEvent) => {
      // Проверяем, что мы действительно покинули страницу
      if (e.clientX === 0 && e.clientY === 0) {
        setDragOverCover(false);
      }
    };

    const handleGlobalDrop = () => {
      // Сбрасываем состояние при drop в любом месте
      setDragOverCover(false);
    };

    document.addEventListener('dragleave', handleGlobalDragLeave);
    document.addEventListener('drop', handleGlobalDrop);

    return () => {
      document.removeEventListener('dragleave', handleGlobalDragLeave);
      document.removeEventListener('drop', handleGlobalDrop);
    };
  }, []);

  const renderBlock = (block: ContentBlock, index: number) => {
    const isHeader = block.isHeader;
    const canMoveUp = index > 1; // Не можем подняться выше первого контентного блока
    const canMoveDown = index < blocks.length - 1;

    // Специальный рендер для header блока
    if (isHeader) {
      return (
        <div key={block.id} className="mb-8">
          <div
            className="bg-[#00051B] rounded-2xl sm:rounded-[32px] border text-white w-full p-3 sm:p-6 lg:p-8 overflow-x-hidden"
            style={{
              borderWidth: '1px',
              borderColor: 'rgba(255, 255, 255, 0.1)',
              display: 'flex',
              flexDirection: 'column',
              gap: '10px',
            }}
          >
            {/* Заголовок поста */}
            <div className="mt-4">
              <RichTextEditor 
                value={block.title || ''} 
                onChange={v => updateBlock(block.id, 'title', v)} 
                label="Заголовок поста" 
                defaultHeading="H1"
                editorId={`${block.id}-title`}
              />
            </div>

            {/* Краткое описание (preview text) */}
            <div className="mt-8">
              <RichTextEditor 
                value={block.description || ''} 
                onChange={v => updateBlock(block.id, 'description', v)} 
                label="Краткое описание (будет показано в превью)"
                rows={4}
                editorId={`${block.id}-description`}
              />
            </div>

            {/* Обложка */}
            <div className="mt-8">
              <div className="mb-2">
                <span className="text-sm text-white/70">Обложка поста</span>
              </div>
              {block.coverImage ? (
                <div 
                  className="relative rounded-3xl overflow-hidden"
                  onDragEnter={(e) => { 
                    if (e.dataTransfer.types.includes('Files')) {
                      e.preventDefault();
                      e.stopPropagation();
                      setDragOverCover(true);
                    }
                  }}
                  onDragOver={(e) => {
                    if (e.dataTransfer.types.includes('Files')) {
                      e.preventDefault();
                      e.stopPropagation();
                      e.dataTransfer.dropEffect = 'copy';
                    }
                  }}
                  onDragLeave={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                    const x = e.clientX;
                    const y = e.clientY;
                    if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) {
                      setDragOverCover(false);
                    }
                  }}
                  onDrop={handleCoverDrop}
                >
                  <img src={block.coverImage} alt="Обложка" className="w-full object-cover max-h-[600px]" />
                  <button 
                    onClick={() => updateBlock(block.id, 'coverImage', '')} 
                    className="absolute top-4 right-4 bg-black/70 p-3 rounded-full text-white hover:bg-black/90 transition-colors"
                  >
                    ✕
                  </button>
                  {dragOverCover && (
                    <div className="absolute inset-0 bg-blue-500/20 border-2 border-dashed border-blue-400 flex items-center justify-center">
                      <div className="text-white text-lg font-medium">Отпустите для замены обложки</div>
                    </div>
                  )}
                </div>
              ) : (
                <div
                  onClick={() => document.getElementById('cover-upload')?.click()}
                  onDragEnter={(e) => { 
                    if (e.dataTransfer.types.includes('Files')) {
                      e.preventDefault();
                      e.stopPropagation();
                      setDragOverCover(true);
                    }
                  }}
                  onDragOver={(e) => {
                    if (e.dataTransfer.types.includes('Files')) {
                      e.preventDefault();
                      e.stopPropagation();
                      e.dataTransfer.dropEffect = 'copy';
                    }
                  }}
                  onDragLeave={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                    const x = e.clientX;
                    const y = e.clientY;
                    if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) {
                      setDragOverCover(false);
                    }
                  }}
                  onDrop={handleCoverDrop}
                  className={`border-2 border-dashed rounded-lg p-8 sm:p-12 text-center cursor-pointer hover:border-white/30 active:border-white/40 transition-colors touch-manipulation min-h-[200px] flex items-center justify-center ${
                    dragOverCover ? 'border-blue-400 bg-blue-500/10' : ''
                  }`}
                  style={{ 
                    borderColor: dragOverCover ? 'rgba(96, 165, 250, 1)' : 'rgba(255, 255, 255, 0.1)', 
                    backgroundColor: dragOverCover ? 'rgba(59, 130, 246, 0.1)' : '#090F1B' 
                  }}
                >
                  <div>
                    <svg className="w-12 h-12 mx-auto mb-4 text-white/40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <span className="text-white/60">
                      {dragOverCover ? 'Отпустите для загрузки обложки' : 'Нажмите или перетащите файл для загрузки обложки'}
                    </span>
                    <p className="text-white/40 text-sm mt-2">Рекомендуемый размер: 1200x800px, до 3МБ</p>
                  </div>
                </div>
              )}
              <input 
                id="cover-upload" 
                type="file" 
                accept="image/*" 
                hidden 
                onChange={e => e.target.files?.[0] && handleCoverImageUpload(e.target.files[0])} 
              />
            </div>
          </div>
        </div>
      );
    }

    // Рендер обычного контентного блока
    return (
      <div key={block.id}>
        <div className="my-6 sm:my-12">
          <div className="border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}></div>
        </div>

        <div
          className="bg-[#00051B] rounded-2xl sm:rounded-[32px] border text-white w-full p-3 sm:p-6 lg:p-8 overflow-x-hidden"
          style={{
            borderWidth: '1px',
            borderColor: 'rgba(255, 255, 255, 0.1)',
            display: 'flex',
            flexDirection: 'column',
            gap: '10px',
          }}
        >
          {/* Кнопки управления */}
          <div className="flex items-center justify-between mb-4 flex-wrap gap-2 sm:gap-3">
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                className="rounded-full flex items-center justify-center hover:bg-white/10 active:bg-white/20 transition-colors disabled:opacity-50 disabled:cursor-not-allowed touch-manipulation"
                style={{ width: '44px', height: '44px', backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => moveBlock(block.id, 'up')}
                disabled={!canMoveUp}
              >
                <svg width="20" height="20" viewBox="0 0 12 12" fill="none">
                  <path d="M3 6L6 3L9 6" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              <button
                className="rounded-full flex items-center justify-center hover:bg-white/10 active:bg-white/20 transition-colors disabled:opacity-50 disabled:cursor-not-allowed touch-manipulation"
                style={{ width: '44px', height: '44px', backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
                onClick={() => moveBlock(block.id, 'down')}
                disabled={!canMoveDown}
              >
                <svg width="20" height="20" viewBox="0 0 12 12" fill="none">
                  <path d="M3 6L6 9L9 6" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </div>
            <button
              className="rounded-lg flex items-center justify-center gap-2 hover:bg-white/10 active:bg-white/20 transition-colors px-3 sm:px-4 py-2.5 sm:py-2 touch-manipulation min-h-[44px]"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
              onClick={() => removeBlock(block.id)}
            >
              <svg width="20" height="20" viewBox="0 0 16 16" fill="none">
                <path d="M5.33333 4H10.6667M6.66667 4V3.33333C6.66667 2.89131 7.02448 2.53333 7.46667 2.53333H8.53333C8.97552 2.53333 9.33333 2.89131 9.33333 3.33333V4M3.33333 4H12.6667L12 13.3333H4L3.33333 4Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <span className="text-xs sm:text-sm font-medium text-white hidden sm:inline">Удалить</span>
            </button>
          </div>

          {/* Заголовок секции */}
          <div className="mt-4">
            <RichTextEditor 
              value={block.title || ''} 
              onChange={v => updateBlock(block.id, 'title', v)} 
              label="Заголовок секции" 
              defaultHeading="H2"
              onImageUpload={(file) => handleImageFileAdd(block.id, file)}
              onAudioUpload={(file) => handleAudioFileAdd(block.id, file)}
              onVideoUpload={(file) => handleVideoFileAdd(block.id, file)}
              editorId={`${block.id}-title`}
            />
          </div>

          {/* Текст секции */}
          <div className="mt-8">
            <RichTextEditor 
              value={block.description || ''} 
              onChange={v => updateBlock(block.id, 'description', v)} 
              label="Текст секции"
              onImageUpload={(file) => handleImageFileAdd(block.id, file)}
              onAudioUpload={(file) => handleAudioFileAdd(block.id, file)}
              onVideoUpload={(file) => handleVideoFileAdd(block.id, file)}
              editorId={`${block.id}-description`}
            />
          </div>

          {/* Загруженные изображения */}
          {block.imageFiles && block.imageFiles.length > 0 && (
            <div className="mt-6 space-y-3">
              <div className="text-sm text-white/70">Изображения:</div>
              {block.imageFiles.map((file, i) => (
                <div key={i} className="relative bg-[#090F1B]/80 rounded-xl p-4 border border-white/10">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <svg className="w-5 h-5 text-white/70 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                      <span className="text-white truncate">{file.name}</span>
                    </div>
                    <button 
                      onClick={() => removeMediaFile(block.id, i, 'image')} 
                      className="text-red-400 hover:text-red-300 text-2xl ml-2 flex-shrink-0"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Загруженные аудио файлы */}
          {block.audioFiles && block.audioFiles.length > 0 && (
            <div className="mt-6 space-y-3">
              <div className="text-sm text-white/70">Аудио файлы:</div>
              {block.audioFiles.map((file, i) => (
                <div key={i} className="relative bg-[#090F1B]/80 rounded-xl p-4 border border-white/10 overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
                    <span className="text-4xl font-bold tracking-widest text-white/5">magiempire</span>
                  </div>
                  <div className="relative flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <svg className="w-5 h-5 text-white/70 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                      </svg>
                      <span className="text-white truncate">{file.name}</span>
                    </div>
                    <button 
                      onClick={() => removeMediaFile(block.id, i, 'audio')} 
                      className="text-red-400 hover:text-red-300 text-2xl ml-2 flex-shrink-0"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Загруженные видео файлы */}
          {block.videoFiles && block.videoFiles.length > 0 && (
            <div className="mt-6 space-y-3">
              <div className="text-sm text-white/70">Видео файлы:</div>
              {block.videoFiles.map((file, i) => (
                <div key={i} className="relative bg-[#090F1B]/80 rounded-xl p-4 border border-white/10">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <svg className="w-5 h-5 text-white/70 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      <span className="text-white truncate">{file.name}</span>
                    </div>
                    <button 
                      onClick={() => removeMediaFile(block.id, i, 'video')} 
                      className="text-red-400 hover:text-red-300 text-2xl ml-2 flex-shrink-0"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <>
        <Header activePage="contents" />
        <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#090F1B' }}>
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#8A63D2]"></div>
        </div>
      </>
    );
  }

  return (
    <>
      <Header activePage="contents" />
      <div className="min-h-screen w-full overflow-x-hidden box-border" style={{ backgroundColor: '#090F1B' }}>
        <div className="w-full sm:max-w-[893px] mx-auto px-3 sm:px-6 lg:px-8 box-border">
          <div className="pt-6 sm:pt-8">
            {/* Все блоки, включая header */}
            {blocks.map((b, i) => renderBlock(b, i))}
          </div>

          <div className="mt-8">
            <button onClick={addBlock} className="w-full py-4 rounded-2xl border text-white text-lg font-medium hover:bg-white/5 transition" style={{ borderColor: 'rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.05)' }}>
              + Добавить блок
            </button>
          </div>

          {/* Настройки */}
          <div className="mt-8 space-y-6">
            <div>
              <label className="block text-sm text-white/70 mb-2">Категория</label>
              <select value={selectedCategory} onChange={e => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-3 rounded-lg bg-[#090F1B] border text-white"
                style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
                {categories.length === 0 ? (
                  <option value="">Загрузка...</option>
                ) : (
                  categories.map(category => (
                    <option key={category.id} value={category.id}>
                      {category.icon} {category.name}
                    </option>
                  ))
                )}
              </select>
            </div>

            <div>
              <label className="block text-sm text-white/70 mb-2">Кому доступен</label>
              <select value={accessibility} onChange={e => setAccessibility(e.target.value as any)}
                className="w-full px-4 py-3 rounded-lg bg-[#090F1B] border text-white"
                style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
                <option value="all">Всем</option>
                <option value="subscribers">Подписчикам</option>
                <option value="my_subscribers">Всем моим подписчикам</option>
              </select>
            </div>

            <label className="flex items-center gap-4 cursor-pointer">
              <input type="checkbox" checked={scheduledPublish} onChange={e => setScheduledPublish(e.target.checked)}
                className="w-6 h-6 rounded border-white/20" />
              <span className="text-lg text-white">Запланировать публикацию</span>
            </label>

            {scheduledPublish && (
              <div className="flex gap-4">
                <input type="date" value={publishDate} onChange={e => setPublishDate(e.target.value)}
                  className="flex-1 px-4 py-3 rounded-lg bg-[#090F1B] border text-white"
                  style={{ borderColor: 'rgba(255,255,255,0.1)' }} />
                <input type="time" value={publishTime} onChange={e => setPublishTime(e.target.value)}
                  className="flex-1 px-4 py-3 rounded-lg bg-[#090F1B] border text-white"
                  style={{ borderColor: 'rgba(255,255,255,0.1)' }} />
              </div>
            )}
          </div>

          <div className="mt-10 flex gap-4 pb-20">
            <button onClick={() => router.push('/contents')}
              className="flex-1 py-4 rounded-xl border text-white font-medium hover:bg-white/5 transition"
              style={{ borderColor: 'rgba(255,255,255,0.1)', backgroundColor: 'rgba(255,255,255,0.05)' }}>
              Отмена
            </button>
            <button onClick={handleSave} disabled={isSaving}
              className="flex-1 py-4 rounded-xl text-white font-medium disabled:opacity-50"
              style={{ backgroundColor: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.2)' }}>
              {isSaving ? 'Сохранение...' : scheduledPublish ? 'Запланировать' : 'Сохранить изменения'}
            </button>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}


