'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getStoredTokens, getPrivacyPolicy } from '@/lib/api';
import { setPageTitle } from '@/lib/setPageTitle';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function AboutPage() {
  const router = useRouter();
  const [policy, setPolicy] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setPageTitle('За нас');
    const { accessToken } = getStoredTokens();
    if (!accessToken) {
      router.push('/signIn');
      return;
    }
    
    loadPrivacyPolicy();
  }, [router]);

  const loadPrivacyPolicy = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await getPrivacyPolicy();
      setPolicy(response);
    } catch (error: any) {
      console.error('Error loading privacy policy:', error);
      setError(error.message || 'Грешка при зареждане на информацията');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#090F1B' }}>
      <Header activePage="about" />
      
      <main className="flex-1 max-w-[1920px] w-full mx-auto px-4 sm:px-6 lg:px-[50px] py-6 sm:py-8 lg:py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-white text-2xl sm:text-3xl lg:text-4xl font-bold mb-6 sm:mb-8 lg:mb-12">
            За нас
          </h1>

          {/* Основная информация */}
          <div className="bg-[#1A1826] rounded-lg border p-6 sm:p-8 mb-6" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
            <h2 className="text-white text-xl sm:text-2xl font-semibold mb-4">
              Добре дошли в Ezoterika
            </h2>
            <div className="text-gray-300 space-y-4">
              <p>
                Ezoterika е платформа за изучаване и обмен на знания в областта на езотериката, 
                астрологията, тарото, нумерологията и духовното развитие.
              </p>
              <p>
                Създадохме пространство, където всеки може да намери качествено съдържание от 
                опитни практикуващи и да сподели своите знания с общността.
              </p>
            </div>
          </div>

          {/* Политика конфиденциальности */}
          {isLoading ? (
            <div className="bg-[#1A1826] rounded-lg border p-6" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
              <div className="text-center py-8">
                <div className="text-white text-lg">Зареждане на политиката за поверителност...</div>
              </div>
            </div>
          ) : error ? (
            <div className="bg-[#1A1826] rounded-lg border p-6" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
              <h2 className="text-white text-xl font-semibold mb-4">
                Политика за поверителност
              </h2>
              <div className="text-gray-400">
                Информацията временно не е достъпна. Моля, опитайте по-късно.
              </div>
            </div>
          ) : policy ? (
            <div className="bg-[#1A1826] rounded-lg border p-6 sm:p-8" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
              <h2 className="text-white text-xl sm:text-2xl font-semibold mb-4">
                {policy.title || 'Политика за поверителност'}
              </h2>
              
              <div 
                className="prose prose-invert max-w-none text-gray-300"
                dangerouslySetInnerHTML={{ __html: policy.content }}
              />
              
              {policy.updated_at && (
                <div className="mt-6 sm:mt-8 pt-6 sm:pt-8 border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
                  <p className="text-gray-400 text-xs sm:text-sm">
                    Последна актуализация: {new Date(policy.updated_at).toLocaleDateString('bg-BG', { 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-[#1A1826] rounded-lg border p-6" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
              <h2 className="text-white text-xl font-semibold mb-4">
                Политика за поверителност
              </h2>
              <div className="text-gray-400">
                Политиката за поверителност ще бъде добавена скоро.
              </div>
            </div>
          )}

          {/* Контакты */}
          <div className="bg-[#1A1826] rounded-lg border p-6 sm:p-8 mt-6" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
            <h2 className="text-white text-xl sm:text-2xl font-semibold mb-4">
              Контакти
            </h2>
            <div className="text-gray-300 space-y-2">
              <p>По всички въпроси можете да се свържете с нас:</p>
              <p>Имейл: <a href="mailto:support@ezoterika.com" className="text-[#8A63D2] hover:text-[#7A53C2]">support@ezoterika.com</a></p>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
