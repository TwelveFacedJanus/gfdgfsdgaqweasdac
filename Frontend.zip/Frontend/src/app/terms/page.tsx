'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getStoredTokens } from '@/lib/api';
import { setPageTitle } from '@/lib/setPageTitle';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function TermsPage() {
  const router = useRouter();

  useEffect(() => {
    setPageTitle('Условия за използване');
    const { accessToken } = getStoredTokens();
    if (!accessToken) {
      router.push('/signIn');
      return;
    }
  }, [router]);

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#090F1B' }}>
      <Header activePage="" />
      
      <main className="flex-1 max-w-[1920px] w-full mx-auto px-4 sm:px-6 lg:px-[50px] py-6 sm:py-8 lg:py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-white text-2xl sm:text-3xl lg:text-4xl font-bold mb-6 sm:mb-8">
            Условия за използване
          </h1>

          <div className="bg-[#1A1826] rounded-lg border p-6 sm:p-8" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
            <div className="text-gray-300 space-y-6">
              <section>
                <h2 className="text-white text-xl font-semibold mb-3">1. Общи положения</h2>
                <p>
                  Настоящите Условия за използване регулират използването на платформата Ezoterika. 
                  Използвайки нашата услуга, вие се съгласявате с тези условия.
                </p>
              </section>

              <section>
                <h2 className="text-white text-xl font-semibold mb-3">2. Регистрация и акаунт</h2>
                <p>
                  За използване на някои функции на платформата е необходима регистрация. 
                  Вие се задължавате да предоставяте точна и актуална информация при регистрация.
                </p>
              </section>

              <section>
                <h2 className="text-white text-xl font-semibold mb-3">3. Съдържание на потребителите</h2>
                <p>
                  Потребителите носят отговорност за съдържанието, което публикуват на платформата. 
                  Съдържанието не трябва да нарушава законодателството или правата на трети лица.
                </p>
              </section>

              <section>
                <h2 className="text-white text-xl font-semibold mb-3">4. Интелектуална собственост</h2>
                <p>
                  Всички материали на платформата са защитени с авторско право. 
                  Използването на материали без разрешение на правообладателите е забранено.
                </p>
              </section>

              <section>
                <h2 className="text-white text-xl font-semibold mb-3">5. Ограничение на отговорността</h2>
                <p>
                  Платформата се предоставя "както е". Ние не носим отговорност за каквито и да е загуби, 
                  възникнали в резултат на използването на услугата.
                </p>
              </section>

              <section>
                <h2 className="text-white text-xl font-semibold mb-3">6. Промени в условията</h2>
                <p>
                  Запазваме си правото да променяме тези условия по всяко време. 
                  Продължаването на използването на платформата след промените означава вашето съгласие с новите условия.
                </p>
              </section>

              <div className="mt-8 pt-8 border-t" style={{ borderColor: 'rgba(255, 255, 255, 0.1)' }}>
                <p className="text-gray-400 text-sm">
                  Последна актуализация: {new Date().toLocaleDateString('bg-BG', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
