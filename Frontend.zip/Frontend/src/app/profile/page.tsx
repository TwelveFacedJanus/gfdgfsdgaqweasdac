'use client';

import { useEffect, useState, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { getStoredTokens, getUserData, updateUserProfile, convertFileToBase64, getUserProfile, getUserHistory, getUserSettings, updateUserSettings, changePassword, getPaymentHistory, getUserSubscriptions, unsubscribeFromUser } from '@/lib/api';
import { setPageTitle } from '@/lib/setPageTitle';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

interface UserProfile {
  id: string;
  fio: string;
  email: string;
  nickname?: string;
  date_of_birth?: string;
  country?: string;
  language?: string;
  base64_image?: string;
  description?: string;
  social_vk?: string;
  social_telegram?: string;
  social_instagram?: string;
  social_facebook?: string;
  social_linkedin?: string;
  social_youtube?: string;
  social_website?: string;
  is_subscribed?: boolean;
  subscribe_expired?: string;
  is_email_verified?: boolean;
}

function ProfileContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [isLoading, setIsLoading] = useState(true);
  const [activeSection, setActiveSection] = useState('data');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [formData, setFormData] = useState({
    nickname: '',
    date_of_birth: '',
    country: 'Россия',
    language: 'ru',
    description: '',
    social_vk: '',
    social_telegram: '',
    social_instagram: '',
    social_facebook: '',
    social_linkedin: '',
    social_youtube: '',
    social_website: '',
  });
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [historyItems, setHistoryItems] = useState<any[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [historyFilters, setHistoryFilters] = useState({
    category: '',
    dateFrom: '',
    dateTo: ''
  });
  const [settingsData, setSettingsData] = useState({
    language: 'ru',
    notifications: {
      email: true,
      internal: true,
      push: true
    },
    subscription: {
      isActive: true,
      expiresAt: '2025-09-20',
      plan: 'premium'
    }
  });
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [subscriptions, setSubscriptions] = useState<any[]>([]);
  const [isLoadingSubscriptions, setIsLoadingSubscriptions] = useState(false);

  useEffect(() => {
    setPageTitle('Профиль');
    const { accessToken } = getStoredTokens();
    if (!accessToken) {
      router.push('/signIn');
      return;
    }

    // Читаем query параметр section для установки активной секции
    const section = searchParams.get('section');
    if (section && ['data', 'history', 'favorites', 'settings'].includes(section)) {
      setActiveSection(section);
    }

    loadUserProfile();
  }, [router, searchParams]);

  useEffect(() => {
    if (activeSection === 'history') {
      loadUserHistory();
    }
  }, [activeSection]);

  useEffect(() => {
    if (activeSection === 'settings') {
      loadUserSettings();
    }
  }, [activeSection]);

  useEffect(() => {
    if (activeSection === 'favorites') {
      loadSubscriptions();
    }
  }, [activeSection]);

  const loadUserProfile = async () => {
    try {
      // Сначала загружаем данные с сервера
      const response = await getUserProfile();
      const serverUserData = response.user;
      
      // Обновляем локальные данные
      setUserProfile(serverUserData);
      setFormData({
        nickname: serverUserData.nickname || '',
        date_of_birth: serverUserData.date_of_birth || '',
        country: serverUserData.country || 'Россия',
        language: serverUserData.language || 'ru',
        description: serverUserData.description || '',
        social_vk: serverUserData.social_vk || '',
        social_telegram: serverUserData.social_telegram || '',
        social_instagram: serverUserData.social_instagram || '',
        social_facebook: serverUserData.social_facebook || '',
        social_linkedin: serverUserData.social_linkedin || '',
        social_youtube: serverUserData.social_youtube || '',
        social_website: serverUserData.social_website || '',
      });
      
      // Сохраняем обновленные данные в localStorage
      localStorage.setItem('user_data', JSON.stringify(serverUserData));
    } catch (error) {
      console.error('Error loading profile from server:', error);
      
      // Fallback к локальным данным
      const localUser = getUserData();
      if (localUser) {
        setUserProfile(localUser);
        setFormData({
          nickname: localUser.nickname || '',
          date_of_birth: localUser.date_of_birth || '',
          country: localUser.country || 'Россия',
          language: localUser.language || 'ru',
          description: localUser.description || '',
          social_vk: localUser.social_vk || '',
          social_telegram: localUser.social_telegram || '',
          social_instagram: localUser.social_instagram || '',
          social_facebook: localUser.social_facebook || '',
          social_linkedin: localUser.social_linkedin || '',
          social_youtube: localUser.social_youtube || '',
          social_website: localUser.social_website || '',
        });
      }
    }
    setIsLoading(false);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const response = await updateUserProfile(formData);
      
      // Обновляем локальные данные с данными с сервера
      if (response.user) {
        setUserProfile(response.user);
        localStorage.setItem('user_data', JSON.stringify(response.user));
      }
      
      // Показываем уведомление об успехе
      alert('Профиль успешно обновлен!');
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Грешка при актуализиране на профила');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    loadUserProfile();
  };

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploadingAvatar(true);
    try {
      const base64Image = await convertFileToBase64(file);
      
      // Обновляем профиль с новой аватаркой
      const response = await updateUserProfile({ base64_image: base64Image });
      
      // Обновляем локальные данные с данными с сервера
      if (response.user) {
        setUserProfile(response.user);
        localStorage.setItem('user_data', JSON.stringify(response.user));
      }
      
      alert('Аватарка успешно обновлена!');
    } catch (error) {
      console.error('Error uploading avatar:', error);
      alert(error instanceof Error ? error.message : 'Грешка при качване на аватар');
    } finally {
      setIsUploadingAvatar(false);
      // Очищаем input
      event.target.value = '';
    }
  };

  const handleAvatarClick = () => {
    const input = document.getElementById('avatar-input') as HTMLInputElement;
    input?.click();
  };

  const handleRemoveAvatar = async () => {
    if (!confirm('Сигурни ли сте, че искате да изтриете аватара?')) return;

    setIsUploadingAvatar(true);
    try {
      const response = await updateUserProfile({ base64_image: null });
      
      // Обновляем локальные данные с данными с сервера
      if (response.user) {
        setUserProfile(response.user);
        localStorage.setItem('user_data', JSON.stringify(response.user));
      }
      
      alert('Аватарка удалена!');
    } catch (error) {
      console.error('Error removing avatar:', error);
      alert('Грешка при изтриване на аватара');
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    localStorage.removeItem('user_data');
    router.push('/signIn');
  };

  const loadUserHistory = async () => {
    setIsLoadingHistory(true);
    try {
      // Используем реальный API
      const response = await getUserHistory(
        historyFilters.category || undefined,
        historyFilters.dateFrom || undefined,
        historyFilters.dateTo || undefined
      );
      setHistoryItems(response.history || []);
    } catch (error) {
      console.error('Error loading history:', error);
      setHistoryItems([]);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const handleFilterChange = (field: string, value: string) => {
    setHistoryFilters(prev => ({
      ...prev,
      [field]: value
    }));
    
    // Автоматически применяем фильтры при изменении
    setTimeout(() => {
      loadUserHistory();
    }, 100);
  };

  const applyHistoryFilters = () => {
    loadUserHistory();
  };

  const loadUserSettings = async () => {
    try {
      const response = await getUserSettings();
      if (response.settings) {
        setSettingsData(response.settings);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      // Fallback к значениям по умолчанию
    }
  };

  const handleSettingsChange = (field: string, value: any) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setSettingsData(prev => ({
        ...prev,
        [parent]: {
          ...(prev[parent as keyof typeof prev] as any),
          [child]: value
        }
      }));
    } else {
      setSettingsData(prev => ({
        ...prev,
        [field]: value
      }));
    }
  };

  const handleSaveSettings = async () => {
    setIsSavingSettings(true);
    try {
      const response = await updateUserSettings(settingsData);
      if (response.settings) {
        setSettingsData(response.settings);
      }
      alert('Настройките са запазени успешно!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Грешка при запазване на настройките');
    } finally {
      setIsSavingSettings(false);
    }
  };

  const handleCancelSettings = () => {
    // Сбрасываем настройки к исходным значениям
    setSettingsData({
      language: 'ru',
      notifications: {
        email: true,
        internal: true,
        push: true
      },
      subscription: {
        isActive: true,
        expiresAt: '2025-09-20',
        plan: 'premium'
      }
    });
  };

  const handleChangePassword = async () => {
    const currentPassword = prompt('Введите текущий пароль:');
    if (!currentPassword) return;
    
    const newPassword = prompt('Введите новый пароль:');
    if (!newPassword) return;
    
    const confirmPassword = prompt('Подтвердите новый пароль:');
    if (newPassword !== confirmPassword) {
      alert('Пароли не совпадают!');
      return;
    }
    
    try {
      await changePassword(currentPassword, newPassword);
      alert('Пароль успешно изменен!');
    } catch (error) {
      console.error('Error changing password:', error);
      alert('Грешка при смяна на паролата');
    }
  };

  const handlePaySubscription = () => {
    router.push('/payment');
  };

  const handleOpenPaymentHistory = async () => {
    try {
      const response = await getPaymentHistory();
      const payments = response.payments || [];
      
      if (payments.length === 0) {
        alert('История платежей пуста');
        return;
      }
      
      // Показываем историю платежей в простом формате
      const historyText = payments.map((payment: any) => 
        `${payment.date}: ${payment.description} - ${payment.amount} ${payment.currency}`
      ).join('\n');
      
      alert(`История платежей:\n\n${historyText}`);
    } catch (error) {
      console.error('Error loading payment history:', error);
      alert('Ошибка при загрузке истории платежей');
    }
  };

  const loadSubscriptions = async () => {
    setIsLoadingSubscriptions(true);
    try {
      const response = await getUserSubscriptions();
      setSubscriptions(response.subscriptions || []);
    } catch (error) {
      console.error('Error loading subscriptions:', error);
      setSubscriptions([]);
    } finally {
      setIsLoadingSubscriptions(false);
    }
  };

  const handleUnsubscribe = async (userId: string, userName: string) => {
    if (!confirm(`Вы уверены, что хотите отписаться от ${userName}?`)) {
      return;
    }

    try {
      await unsubscribeFromUser(userId);
      // Обновляем список подписок
      setSubscriptions(prev => prev.filter(sub => sub.subscribed_to !== userId));
      alert('Вы успешно отписались');
    } catch (error: any) {
      console.error('Error unsubscribing:', error);
      alert(error.message || 'Ошибка при отписке');
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU');
  };

  const navigationItems = [
    { id: 'data', label: 'Данни' },
    { id: 'history', label: 'История' },
    { id: 'favorites', label: 'Любими' },
    { id: 'settings', label: 'Настройки' },
  ];

  const getSectionTitle = () => {
    const currentItem = navigationItems.find(item => item.id === activeSection);
    return currentItem ? currentItem.label : 'Профиль';
  };

  if (isLoading) {
    return (
      <>
        <Header activePage="profile" />
        <div 
          className="min-h-screen"
          style={{ 
            backgroundColor: '#090F1B'
          }}
        >
          <div className="container mx-auto px-4 py-8">
            <div className="max-w-7xl mx-auto">
              <div className="flex gap-8">
                <div className="w-64">
                  <div className="bg-[#1A1826] rounded-lg p-6 animate-pulse">
                    <div className="h-8 bg-gray-600 rounded w-1/2 mb-6"></div>
                    <div className="space-y-3">
                      {[...Array(4)].map((_, i) => (
                        <div key={i} className="h-6 bg-gray-600 rounded w-full"></div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="bg-[#1A1826] rounded-lg p-8 animate-pulse">
                    <div className="space-y-6">
                      {[...Array(5)].map((_, i) => (
                        <div key={i}>
                          <div className="h-4 bg-gray-600 rounded w-1/4 mb-2"></div>
                          <div className="h-10 bg-gray-600 rounded w-full"></div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Header activePage="profile" />
      <div 
        className="min-h-screen"
        style={{ 
          backgroundColor: '#090F1B'
        }}
      >
        <div className="w-full max-w-full mx-auto px-2 sm:px-4 md:px-6 lg:px-8 py-3 sm:py-4 md:py-6 lg:py-8">
          <div className="max-w-7xl mx-auto w-full">
            {/* Заголовок */}
            <h1 className="text-white mb-4 sm:mb-6 text-2xl sm:text-3xl lg:text-5xl font-semibold sm:font-bold" style={{ lineHeight: '120%', letterSpacing: '0%' }}>Профиль</h1>
            
            <div className="bg-[#1A1826] rounded-lg p-4 sm:p-6 lg:p-8 w-full max-w-[886px]">
              <div className="flex flex-col lg:flex-row gap-3 sm:gap-4 lg:gap-8 w-full">
                {/* Левая навигация */}
                <div className="w-full lg:w-64 flex flex-row lg:flex-col overflow-x-auto lg:overflow-x-visible scrollbar-hide" style={{ minHeight: 'auto', gap: '8px', WebkitOverflowScrolling: 'touch' }}>
                  <nav className="flex lg:flex-col space-x-2 lg:space-x-0 lg:space-y-2 mb-0 lg:mb-8">
                    {navigationItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setActiveSection(item.id)}
                        className={`whitespace-nowrap text-left py-2.5 lg:py-3 transition-colors text-sm lg:text-base touch-manipulation ${
                          activeSection === item.id
                            ? 'bg-[#8A63D2] text-white px-3 lg:px-4 rounded-lg'
                            : 'text-gray-400 active:bg-[#333333] sm:hover:bg-[#333333] px-3 lg:px-4 rounded-lg'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                    <button
                      onClick={handleLogout}
                      className="whitespace-nowrap text-left py-2 lg:py-3 transition-colors text-sm lg:text-base text-white hover:text-gray-300 hover:bg-[#333333] px-3 lg:px-4 rounded-lg flex items-center lg:justify-start justify-center space-x-2 lg:mt-auto lg:pt-4"
                    >
                      <span>Выйти</span>
                      <svg className="w-4 h-4 hidden lg:block" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                  </nav>
                </div>

                {/* Основной контент */}
                <div className="flex-1 min-w-0">
                  {activeSection === 'data' && (
                    <div className="space-y-4 sm:space-y-6">
                      {/* Аватар */}
                      <div className="flex flex-col sm:flex-row items-start gap-4">
                        <div className="flex-1 w-full">
                          <label className="block text-white text-sm font-medium mb-2">
                            Аватар
                          </label>
                          <p className="text-gray-400 text-sm">
                            Кликнете на снимката за да актуализирате<br className="hidden sm:block" />или изтриете аватара
                          </p>
                        </div>
                        <div className="w-20 h-20 sm:w-24 sm:h-24 relative flex-shrink-0">
                          {userProfile?.base64_image ? (
                            <img 
                              src={userProfile.base64_image} 
                              alt="Аватар"
                              className={`w-full h-full rounded-full object-cover cursor-pointer hover:opacity-80 transition-opacity ${
                                isUploadingAvatar ? 'opacity-50' : ''
                              }`}
                              onClick={handleAvatarClick}
                            />
                          ) : (
                            <div 
                              className={`w-full h-full rounded-full bg-gray-600 flex items-center justify-center cursor-pointer hover:bg-gray-500 transition-colors ${
                                isUploadingAvatar ? 'opacity-50' : ''
                              }`}
                              onClick={handleAvatarClick}
                            >
                              <svg className="w-10 h-10 sm:w-12 sm:h-12 text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                              </svg>
                            </div>
                          )}
                          
                          {/* Индикатор загрузки */}
                          {isUploadingAvatar && (
                            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full">
                              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Скрытый input для загрузки файла */}
                      <input
                        id="avatar-input"
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarUpload}
                        className="hidden"
                      />

                      {/* Никнейм */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">
                          Никнейм
                        </label>
                        <input
                          type="text"
                          value={formData.nickname}
                          onChange={(e) => handleInputChange('nickname', e.target.value)}
                          className="w-full px-4 py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors"
                          placeholder="Введите никнейм"
                        />
                      </div>

                      {/* Почта */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">
                          Почта
                        </label>
                        <p className="text-gray-400 text-sm mb-2">Не редактируется</p>
                        <input
                          type="email"
                          value={userProfile?.email || ''}
                          disabled
                          className="w-full px-4 py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 cursor-not-allowed opacity-60"
                        />
                        {/* Статус верификации */}
                        <div className="mt-2 flex items-center gap-2">
                          {userProfile?.is_email_verified ? (
                            <>
                              <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              </svg>
                              <span className="text-green-500 text-sm">Почта верифицирована</span>
                            </>
                          ) : (
                            <>
                              <svg className="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                              </svg>
                              <span className="text-amber-500 text-sm">Почта не верифицирована</span>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Дата рождения */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">
                          Дата рождения
                        </label>
                        <input
                          type="date"
                          value={formData.date_of_birth}
                          onChange={(e) => handleInputChange('date_of_birth', e.target.value)}
                          className="w-full px-4 py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors"
                        />
                      </div>

                      {/* Страна */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">
                          Страна
                        </label>
                        <select
                          value={formData.country}
                          onChange={(e) => handleInputChange('country', e.target.value)}
                          className="w-full px-4 py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white focus:outline-none focus:border-[#8A63D2] transition-colors appearance-none cursor-pointer"
                        >
                          <option value="Россия">Россия</option>
                          <option value="Беларусь">Беларусь</option>
                          <option value="Казахстан">Казахстан</option>
                          <option value="Украина">Украина</option>
                          <option value="Другая">Другая</option>
                        </select>
                      </div>

                      {/* Язык */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">
                          Язык
                        </label>
                        <select
                          value={formData.language}
                          onChange={(e) => handleInputChange('language', e.target.value)}
                          className="w-full px-4 py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white focus:outline-none focus:border-[#8A63D2] transition-colors appearance-none cursor-pointer"
                        >
                          <option value="ru">Русский</option>
                          <option value="en">English</option>
                          <option value="de">Deutsch</option>
                          <option value="fr">Français</option>
                        </select>
                      </div>

                      {/* Описание профиля */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">
                          Описание профиля
                        </label>
                        <textarea
                          value={formData.description}
                          onChange={(e) => handleInputChange('description', e.target.value)}
                          rows={4}
                          maxLength={500}
                          className="w-full px-4 py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors resize-none"
                          placeholder="Расскажите о себе..."
                        />
                        <div className="text-right text-gray-400 text-xs mt-1">
                          {formData.description.length}/500
                        </div>
                      </div>

                      {/* Социальные сети */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-3">
                          Социальные сети
                        </label>
                        <div className="space-y-3">
                          {/* VK */}
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#0077FF] rounded-lg flex items-center justify-center flex-shrink-0">
                              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.14C2 20.67 3.33 22 8.93 22h6.14c5.6 0 6.93-1.33 6.93-6.93V8.93C22 3.33 20.67 2 15.07 2zm3.45 14.41h-1.31c-.57 0-.74-.46-1.76-1.48-.89-.89-1.28-1.01-1.5-1.01-.31 0-.4.09-.4.52v1.35c0 .36-.12.58-1.06.58-1.56 0-3.29-.94-4.51-2.7-1.84-2.62-2.34-4.58-2.34-4.98 0-.22.09-.43.52-.43h1.31c.39 0 .54.18.69.6.74 2.14 1.98 4.01 2.49 4.01.19 0 .28-.09.28-.58v-2.25c-.06-.99-.58-1.08-.58-1.43 0-.18.15-.36.39-.36h2.06c.33 0 .45.18.45.57v3.04c0 .33.15.45.24.45.19 0 .35-.12.7-.47 1.08-1.21 1.85-3.08 1.85-3.08.1-.21.28-.43.72-.43h1.31c.47 0 .57.24.47.57-.15.81-1.91 3.47-1.91 3.47-.16.26-.22.37 0 .66.16.21.69.68 1.05 1.08.65.75 1.15 1.38 1.28 1.81.14.43-.07.65-.5.65z"/>
                              </svg>
                            </div>
                            <input
                              type="url"
                              value={formData.social_vk}
                              onChange={(e) => handleInputChange('social_vk', e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors text-sm"
                              placeholder="https://vk.com/username"
                            />
                          </div>

                          {/* Telegram */}
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#0088CC] rounded-lg flex items-center justify-center flex-shrink-0">
                              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
                              </svg>
                            </div>
                            <input
                              type="text"
                              value={formData.social_telegram}
                              onChange={(e) => handleInputChange('social_telegram', e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors text-sm"
                              placeholder="@username или https://t.me/username"
                            />
                          </div>

                          {/* Instagram */}
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-[#833AB4] via-[#FD1D1D] to-[#F77737] rounded-lg flex items-center justify-center flex-shrink-0">
                              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                              </svg>
                            </div>
                            <input
                              type="url"
                              value={formData.social_instagram}
                              onChange={(e) => handleInputChange('social_instagram', e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors text-sm"
                              placeholder="https://instagram.com/username"
                            />
                          </div>

                          {/* Facebook */}
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#1877F2] rounded-lg flex items-center justify-center flex-shrink-0">
                              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                              </svg>
                            </div>
                            <input
                              type="url"
                              value={formData.social_facebook}
                              onChange={(e) => handleInputChange('social_facebook', e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors text-sm"
                              placeholder="https://facebook.com/username"
                            />
                          </div>

                          {/* LinkedIn */}
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#0A66C2] rounded-lg flex items-center justify-center flex-shrink-0">
                              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                              </svg>
                            </div>
                            <input
                              type="url"
                              value={formData.social_linkedin}
                              onChange={(e) => handleInputChange('social_linkedin', e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors text-sm"
                              placeholder="https://linkedin.com/in/username"
                            />
                          </div>

                          {/* YouTube */}
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#FF0000] rounded-lg flex items-center justify-center flex-shrink-0">
                              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                              </svg>
                            </div>
                            <input
                              type="url"
                              value={formData.social_youtube}
                              onChange={(e) => handleInputChange('social_youtube', e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors text-sm"
                              placeholder="https://youtube.com/@username"
                            />
                          </div>

                          {/* Website */}
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#6B7280] rounded-lg flex items-center justify-center flex-shrink-0">
                              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                              </svg>
                            </div>
                            <input
                              type="url"
                              value={formData.social_website}
                              onChange={(e) => handleInputChange('social_website', e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-[#8A63D2] transition-colors text-sm"
                              placeholder="https://yourwebsite.com"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Кнопки действий */}
                      <div className="flex justify-end space-x-4 pt-6">
                        <button
                          onClick={handleCancel}
                          className="px-6 py-3 bg-[#1A1826] border border-gray-600 text-white rounded-lg hover:bg-[#2A2A2A] transition-colors"
                        >
                          Отменить
                        </button>
                        <button
                          onClick={handleSave}
                          disabled={isSaving}
                          className="px-6 py-3 bg-[#8A63D2] text-white rounded-lg hover:bg-[#7A53C2] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {isSaving ? 'Запазване...' : 'Запази'}
                        </button>
                      </div>
                    </div>
                  )}

                  {activeSection === 'history' && (
                    <div className="space-y-4 sm:space-y-6">
                      {/* Фильтры */}
                      <div className="flex flex-col sm:flex-row gap-4 w-full">
                        <div className="flex-1 w-full min-w-0">
                          <label className="block text-white text-sm font-medium mb-2">
                            Выберите категорию
                          </label>
                          <select
                            value={historyFilters.category}
                            onChange={(e) => handleFilterChange('category', e.target.value)}
                            className="w-full px-3 sm:px-4 py-2 sm:py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white focus:outline-none focus:border-[#8A63D2] transition-colors appearance-none cursor-pointer text-sm sm:text-base"
                          >
                            <option value="">Все категории</option>
                            <option value="registration">Регистрация</option>
                            <option value="favorites">Подписки</option>
                            <option value="content">Контент</option>
                            <option value="subscription">Абонемент</option>
                          </select>
                        </div>
                        <div className="flex-1 w-full min-w-0">
                          <label className="block text-white text-sm font-medium mb-2">
                            Период
                          </label>
                          <div className="flex gap-2 items-center">
                            <input
                              type="date"
                              value={historyFilters.dateFrom}
                              onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                              className="flex-1 min-w-0 px-2 sm:px-4 py-2 sm:py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white focus:outline-none focus:border-[#8A63D2] transition-colors text-sm sm:text-base"
                            />
                            <span className="text-white text-sm sm:text-base flex-shrink-0">-</span>
                            <input
                              type="date"
                              value={historyFilters.dateTo}
                              onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                              className="flex-1 min-w-0 px-2 sm:px-4 py-2 sm:py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white focus:outline-none focus:border-[#8A63D2] transition-colors text-sm sm:text-base"
                            />
                          </div>
                        </div>
                      </div>

                      {/* Список истории */}
                      <div className="space-y-3 sm:space-y-4">
                        {isLoadingHistory ? (
                          <div className="space-y-3">
                            {[...Array(4)].map((_, i) => (
                              <div key={i} className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0 py-3 border-b border-gray-700 animate-pulse">
                                <div className="h-4 bg-gray-600 rounded w-full sm:w-3/4"></div>
                                <div className="h-4 bg-gray-600 rounded w-1/2 sm:w-1/4"></div>
                              </div>
                            ))}
                          </div>
                        ) : historyItems.length > 0 ? (
                          <>
                            <div className="text-xs sm:text-sm text-gray-400 mb-2">
                              Загружено {historyItems.length} записей
                            </div>
                            {historyItems.map((item: any) => {
                              const getIcon = () => {
                                switch (item.type) {
                                  case 'user_registration':
                                    return (
                                      <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                                      </svg>
                                    );
                                  case 'user_subscription':
                                    return (
                                      <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                      </svg>
                                    );
                                  case 'post_created':
                                    return (
                                      <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                      </svg>
                                    );
                                  case 'comment_created':
                                    return (
                                      <svg className="w-5 h-5 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                                      </svg>
                                    );
                                  case 'subscription_activated':
                                    return (
                                      <svg className="w-5 h-5 text-[#8A63D2]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                      </svg>
                                    );
                                  default:
                                    return (
                                      <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                      </svg>
                                    );
                                }
                              };

                              return (
                                <div 
                                  key={item.id} 
                                  className="flex items-start gap-3 sm:gap-4 py-3 border-b border-gray-700 hover:bg-[#2A2A2A]/50 transition-colors"
                                >
                                  <div className="flex-shrink-0 mt-0.5">
                                    {getIcon()}
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 sm:gap-2">
                                      <div className="flex-1 min-w-0">
                                        <p className="text-white text-sm sm:text-base break-words">
                                          {item.description}
                                        </p>
                                        {item.related_user && (
                                          <div className="flex items-center gap-2 mt-1">
                                            {item.related_user.avatar && (
                                              <img 
                                                src={item.related_user.avatar.startsWith('data:') 
                                                  ? item.related_user.avatar 
                                                  : `data:image/png;base64,${item.related_user.avatar}`}
                                                alt={item.related_user.fio}
                                                className="w-5 h-5 rounded-full object-cover"
                                              />
                                            )}
                                            <span className="text-gray-400 text-xs">
                                              {item.related_user.fio}
                                            </span>
                                          </div>
                                        )}
                                        {item.related_post && (
                                          <Link 
                                            href={`/posts/${item.related_post.id}`}
                                            className="text-[#8A63D2] hover:text-[#7A53C2] text-xs sm:text-sm mt-1 inline-block"
                                          >
                                            Перейти к посту →
                                          </Link>
                                        )}
                                      </div>
                                      <div className="flex flex-col items-end sm:items-end gap-1 flex-shrink-0">
                                        <span className="text-gray-400 text-xs sm:text-sm whitespace-nowrap">
                                          {formatDate(item.date)}
                                        </span>
                                        {item.time && (
                                          <span className="text-gray-500 text-xs whitespace-nowrap">
                                            {item.time}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </>
                        ) : (
                          <div className="text-center py-8 sm:py-12">
                            <div className="text-gray-400 text-base sm:text-lg">
                              Историята на активността е празна
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {activeSection === 'favorites' && (
                    <div className="space-y-4 sm:space-y-6">
                      <div>
                        <h2 className="text-white text-xl font-semibold mb-4">
                          Мои подписки
                        </h2>
                        <p className="text-gray-400 text-sm mb-6">
                          Список авторов, на которых вы подписаны
                        </p>
                      </div>

                      {isLoadingSubscriptions ? (
                        <div className="space-y-3">
                          {[...Array(4)].map((_, i) => (
                            <div key={i} className="flex items-center gap-4 p-4 bg-[#2A2A2A] rounded-lg animate-pulse">
                              <div className="w-12 h-12 bg-gray-600 rounded-full"></div>
                              <div className="flex-1">
                                <div className="h-4 bg-gray-600 rounded w-1/3 mb-2"></div>
                                <div className="h-3 bg-gray-600 rounded w-1/4"></div>
                              </div>
                              <div className="h-8 bg-gray-600 rounded w-24"></div>
                            </div>
                          ))}
                        </div>
                      ) : subscriptions.length > 0 ? (
                        <div className="space-y-3">
                          {subscriptions.map((subscription) => (
                            <div 
                              key={subscription.id || subscription.subscribed_to} 
                              className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 bg-[#2A2A2A] rounded-lg border border-gray-700 hover:border-gray-600 transition-colors"
                            >
                              <div className="flex items-center gap-4 flex-1 min-w-0">
                                {/* Аватар */}
                                <div className="w-12 h-12 sm:w-14 sm:h-14 flex-shrink-0">
                                  {subscription.subscribed_to_avatar ? (
                                    <img 
                                      src={subscription.subscribed_to_avatar.startsWith('data:') 
                                        ? subscription.subscribed_to_avatar 
                                        : `data:image/png;base64,${subscription.subscribed_to_avatar}`}
                                      alt={subscription.subscribed_to_fio}
                                      className="w-full h-full rounded-full object-cover"
                                    />
                                  ) : (
                                    <div className="w-full h-full rounded-full bg-gray-600 flex items-center justify-center">
                                      <svg className="w-6 h-6 sm:w-8 sm:h-8 text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                                      </svg>
                                    </div>
                                  )}
                                </div>

                                {/* Информация о пользователе */}
                                <div className="flex-1 min-w-0">
                                  <h3 className="text-white font-medium text-base sm:text-lg truncate">
                                    {subscription.subscribed_to_fio || 'Пользователь'}
                                  </h3>
                                  {subscription.subscribed_to_nickname && (
                                    <p className="text-gray-400 text-sm truncate">
                                      @{subscription.subscribed_to_nickname}
                                    </p>
                                  )}
                                  {subscription.subscribed_to_rating !== undefined && (
                                    <p className="text-gray-500 text-xs mt-1">
                                      Рейтинг: {subscription.subscribed_to_rating}
                                    </p>
                                  )}
                                  {subscription.created_at && (
                                    <p className="text-gray-500 text-xs mt-1">
                                      Подписан с {formatDate(subscription.created_at)}
                                    </p>
                                  )}
                                </div>
                              </div>

                              {/* Кнопка отписки */}
                              <button
                                onClick={() => handleUnsubscribe(
                                  subscription.subscribed_to, 
                                  subscription.subscribed_to_fio || 'пользователя'
                                )}
                                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors text-sm sm:text-base whitespace-nowrap flex-shrink-0"
                              >
                                Отписаться
                              </button>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <div className="text-gray-400 text-lg mb-2">
                            У вас пока нет подписок
                          </div>
                          <p className="text-gray-500 text-sm">
                            Подписывайтесь на авторов статей, чтобы видеть их контент первыми
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {activeSection === 'settings' && (
                    <div className="space-y-8">
                      {/* Язык интерфейса */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-3">
                          Язык интерфейса
                        </label>
                        <select
                          value={settingsData.language}
                          onChange={(e) => handleSettingsChange('language', e.target.value)}
                          className="w-full px-4 py-3 bg-[#2A2A2A] border border-gray-600 rounded-lg text-white focus:outline-none focus:border-[#8A63D2] transition-colors appearance-none cursor-pointer"
                        >
                          <option value="ru">Русский</option>
                          <option value="en">English</option>
                          <option value="de">Deutsch</option>
                          <option value="fr">Français</option>
                        </select>
                      </div>

                      {/* Уведомления */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-3">
                          Известия
                        </label>
                        <div className="space-y-3">
                          <label className="flex items-center space-x-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={settingsData.notifications.email}
                              onChange={(e) => handleSettingsChange('notifications.email', e.target.checked)}
                              className="w-5 h-5 text-[#8A63D2] bg-[#2A2A2A] border-gray-600 rounded focus:ring-[#8A63D2] focus:ring-2"
                            />
                            <span className="text-white">Почта</span>
                          </label>
                          <label className="flex items-center space-x-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={settingsData.notifications.internal}
                              onChange={(e) => handleSettingsChange('notifications.internal', e.target.checked)}
                              className="w-5 h-5 text-[#8A63D2] bg-[#2A2A2A] border-gray-600 rounded focus:ring-[#8A63D2] focus:ring-2"
                            />
                            <span className="text-white">Внутренние</span>
                          </label>
                          <label className="flex items-center space-x-3 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={settingsData.notifications.push}
                              onChange={(e) => handleSettingsChange('notifications.push', e.target.checked)}
                              className="w-5 h-5 text-[#8A63D2] bg-[#2A2A2A] border-gray-600 rounded focus:ring-[#8A63D2] focus:ring-2"
                            />
                            <span className="text-white">Пуш</span>
                          </label>
                        </div>
                      </div>

                      {/* Управление подпиской 
                      <div>
                        <label className="block text-white text-sm font-medium mb-3">
                          Управление подпиской
                        </label>
                        {userProfile?.is_subscribed ? (
                          <div className="space-y-4">
                            <div className="text-gray-300">
                              Активно до {userProfile.subscribe_expired ? formatDate(userProfile.subscribe_expired) : 'не указано'}
                            </div>
                            <div className="flex space-x-3">
                              <button className="px-4 py-2 bg-[#2A2A2A] text-white rounded-lg hover:bg-[#3A3A3A] transition-colors">
                                Сменить план
                              </button>
                              <button className="px-4 py-2 bg-[#2A2A2A] text-white rounded-lg hover:bg-[#3A3A3A] transition-colors">
                                Отменить подписку
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <div className="text-gray-300">
                              У вас нет активной подписки
                            </div>
                            <button 
                              onClick={handlePaySubscription}
                              className="px-6 py-3 bg-[#8A63D2] text-white rounded-lg hover:bg-[#7A53C2] transition-colors"
                            >
                              Оплатить
                            </button>
                          </div>
                        )}
                      </div>
                      */}

                      {/* Безопасность */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-3">
                          Сигурност
                        </label>
                        <button 
                          onClick={handleChangePassword}
                          className="px-4 py-2 bg-[#2A2A2A] text-white rounded-lg hover:bg-[#3A3A3A] transition-colors"
                        >
                          Сменить пароль
                        </button>
                      </div>

                      {/* История платежей */}
                      <div>
                        <label className="block text-white text-sm font-medium mb-3">
                          История на плащанията
                        </label>
                        <button 
                          onClick={handleOpenPaymentHistory}
                          className="px-4 py-2 bg-[#2A2A2A] text-white rounded-lg hover:bg-[#3A3A3A] transition-colors"
                        >
                          Открыть
                        </button>
                      </div>

                      {/* Статус абонемента */}
                      {userProfile?.is_subscribed && (
                        <div>
                          <label className="block text-white text-sm font-medium mb-3">
                            Статус абонемента
                          </label>
                          <div className="flex items-center space-x-2">
                            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                            <span className="text-white">Активен</span>
                          </div>
                          
                          {/* Информационное сообщение */}
                          <div className="mt-4 p-4 bg-[#2A2A2A] border border-gray-600 rounded-lg">
                            <div className="flex items-start space-x-3">
                              <div className="w-6 h-6 bg-gray-600 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                                <span className="text-white text-xs font-bold">i</span>
                              </div>
                              <div className="text-gray-300 text-sm">
                                Уведомления о предстоящем продлении или списании
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Кнопки действий */}
                      <div className="flex justify-end space-x-4 pt-6">
                        <button
                          onClick={handleCancelSettings}
                          className="px-6 py-3 bg-[#1A1826] border border-gray-600 text-white rounded-lg hover:bg-[#2A2A2A] transition-colors"
                        >
                          Отменить
                        </button>
                        <button
                          onClick={handleSaveSettings}
                          disabled={isSavingSettings}
                          className="px-6 py-3 bg-[#8A63D2] text-white rounded-lg hover:bg-[#7A53C2] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {isSavingSettings ? 'Запазване...' : 'Запази'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default function ProfilePage() {
  return (
    <Suspense fallback={
      <>
        <Header activePage="profile" />
        <div 
          className="min-h-screen flex items-center justify-center"
          style={{ backgroundColor: '#090F1B' }}
        >
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#8A63D2]"></div>
        </div>
      </>
    }>
      <ProfileContent />
    </Suspense>
  );
}
