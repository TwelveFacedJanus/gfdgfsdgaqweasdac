'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { getStoredTokens, getUserData, checkSubscriptionStatus, subscribeToUser, unsubscribeFromUser, apiRequest } from '@/lib/api';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

interface UserProfile {
  id: string;
  fio: string;
  email: string;
  nickname?: string;
  date_of_birth?: string;
  country?: string;
  language?: string;
  base64_image?: string;
  description?: string;
  social_vk?: string;
  social_telegram?: string;
  social_instagram?: string;
  social_facebook?: string;
  social_linkedin?: string;
  social_youtube?: string;
  social_website?: string;
  rating: number;
  is_subscribed?: boolean;
  subscribe_expired?: string;
  is_email_verified?: boolean;
}

interface UserPost {
  id: string;
  title: string;
  preview_text: string;
  preview_image_link?: string;
  rating: string;
  comments_count: number;
  views_count: number;
  category_display: string;
  created_at: string;
}

export default function UserProfilePage() {
  const router = useRouter();
  const params = useParams();
  const userId = params.id as string;
  
  const [isLoading, setIsLoading] = useState(true);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [userPosts, setUserPosts] = useState<UserPost[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isSubscriptionLoading, setIsSubscriptionLoading] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [isLoadingPosts, setIsLoadingPosts] = useState(false);

  useEffect(() => {
    const { accessToken } = getStoredTokens();
    if (!accessToken) {
      router.push('/signIn');
      return;
    }

    const userData = getUserData();
    if (userData && userData.id) {
      setCurrentUserId(userData.id);
      
      // Если пользователь пытается посмотреть свой профиль, перенаправляем на /profile
      if (userData.id === userId) {
        router.push('/profile');
        return;
      }
    }

    if (userId) {
      loadUserProfile();
    }
  }, [userId, router]);

  const loadUserProfile = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      // Загружаем профиль пользователя
      const profileResponse = await apiRequest(`/api/user/profile/${userId}/`, {
        method: 'GET',
      });
      
      setUserProfile(profileResponse.user);
      
      // Загружаем посты пользователя
      setIsLoadingPosts(true);
      try {
        const postsResponse = await apiRequest(`/api/content/author/${userId}/posts/`, {
          method: 'GET',
        });
        
        console.log('Posts response:', postsResponse); // Отладка
        setUserPosts(postsResponse.posts || []);
      } catch (postsError) {
        console.error('Error loading user posts:', postsError);
        setUserPosts([]);
      } finally {
        setIsLoadingPosts(false);
      }
      
      // Проверяем статус подписки
      try {
        const statusResponse = await checkSubscriptionStatus(userId);
        setIsSubscribed(statusResponse.is_subscribed || false);
      } catch (error) {
        console.error('Error checking subscription status:', error);
        setIsSubscribed(false);
      }
    } catch (error: any) {
      console.error('Error loading user profile:', error);
      setError(error.message || 'Грешка при зареждане на профила');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubscribe = async () => {
    if (!userId) return;

    setIsSubscriptionLoading(true);
    try {
      if (isSubscribed) {
        await unsubscribeFromUser(userId);
        setIsSubscribed(false);
      } else {
        await subscribeToUser(userId);
        setIsSubscribed(true);
      }
    } catch (error: any) {
      console.error('Subscription error:', error);
      alert(error.message || 'Грешка при промяна на абонамента');
    } finally {
      setIsSubscriptionLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU');
  };

  if (isLoading) {
    return (
      <>
        <Header activePage="" />
        <div 
          className="min-h-screen"
          style={{ backgroundColor: '#090F1B' }}
        >
          <div className="container mx-auto px-4 py-8">
            <div className="max-w-4xl mx-auto">
              <div className="bg-[#1A1826] rounded-lg p-8 animate-pulse">
                <div className="flex items-center gap-6 mb-6">
                  <div className="w-24 h-24 bg-gray-600 rounded-full"></div>
                  <div className="flex-1">
                    <div className="h-8 bg-gray-600 rounded w-1/3 mb-2"></div>
                    <div className="h-4 bg-gray-600 rounded w-1/4"></div>
                  </div>
                </div>
                <div className="space-y-3">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="h-4 bg-gray-600 rounded w-full"></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  if (error || !userProfile) {
    return (
      <>
        <Header activePage="" />
        <div 
          className="min-h-screen"
          style={{ backgroundColor: '#090F1B' }}
        >
          <div className="container mx-auto px-4 py-8">
            <div className="max-w-4xl mx-auto">
              <div className="bg-[#1A1826] rounded-lg p-8 text-center">
                <div className="text-red-400 text-xl mb-4">
                  {error || 'Профилът не е намерен'}
                </div>
                <button
                  onClick={() => router.back()}
                  className="px-6 py-2 bg-[#8A63D2] text-white rounded-lg hover:bg-[#7A53C2] transition-colors"
                >
                  Назад
                </button>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Header activePage="" />
      <div 
        className="min-h-screen"
        style={{ backgroundColor: '#090F1B' }}
      >
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Кнопка назад */}
            <button
              onClick={() => router.back()}
              className="mb-6 inline-flex items-center space-x-2 px-4 py-2 bg-[#1A1826] border border-gray-600 rounded-lg text-gray-300 hover:text-white hover:border-gray-500 transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              <span>Назад</span>
            </button>

            {/* Профиль пользователя */}
            <div className="bg-[#1A1826] rounded-lg p-6 sm:p-8 mb-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6 mb-6">
                {/* Аватар */}
                <div className="w-24 h-24 sm:w-32 sm:h-32 flex-shrink-0">
                  {userProfile.base64_image ? (
                    <img 
                      src={userProfile.base64_image} 
                      alt={userProfile.fio}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full rounded-full bg-gray-600 flex items-center justify-center">
                      <svg className="w-16 h-16 text-gray-300" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                      </svg>
                    </div>
                  )}
                </div>

                {/* Информация */}
                <div className="flex-1">
                  <h1 className="text-3xl font-bold text-white mb-2">
                    {userProfile.fio}
                  </h1>
                  {userProfile.nickname && (
                    <p className="text-gray-400 text-lg mb-2">
                      @{userProfile.nickname}
                    </p>
                  )}
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <div className="flex items-center gap-1">
                      <svg className="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                      <span>Рейтинг: {userProfile.rating}</span>
                    </div>
                    {userProfile.country && (
                      <span>📍 {userProfile.country}</span>
                    )}
                  </div>
                </div>

                {/* Кнопка подписки */}
                <button
                  onClick={handleSubscribe}
                  disabled={isSubscriptionLoading}
                  className={`px-6 py-3 rounded-lg font-medium transition-colors ${
                    isSubscribed
                      ? 'bg-gray-600 text-white hover:bg-gray-700'
                      : 'bg-[#8A63D2] text-white hover:bg-[#7A53C2]'
                  } ${isSubscriptionLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  {isSubscriptionLoading ? (
                    <span className="flex items-center gap-2">
                      <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Зареждане...
                    </span>
                  ) : isSubscribed ? (
                    '✓ Абониран'
                  ) : (
                    '+ Абонирай се'
                  )}
                </button>
              </div>

              {/* Описание */}
              {userProfile.description && (
                <div className="mb-6">
                  <h2 className="text-xl font-semibold text-white mb-3">За себе си</h2>
                  <p className="text-gray-300 whitespace-pre-wrap">{userProfile.description}</p>
                </div>
              )}

              {/* Социальные сети */}
              {(() => {
                // Собираем только заполненные социальные сети
                const socialLinks = [];
                
                if (userProfile.social_vk) {
                  socialLinks.push(
                    <a
                      key="vk"
                      href={userProfile.social_vk}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 bg-[#0077FF] rounded-lg text-white hover:opacity-80 transition-opacity"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M15.07 2H8.93C3.33 2 2 3.33 2 8.93v6.14C2 20.67 3.33 22 8.93 22h6.14c5.6 0 6.93-1.33 6.93-6.93V8.93C22 3.33 20.67 2 15.07 2zm3.45 14.41h-1.31c-.57 0-.74-.46-1.76-1.48-.89-.89-1.28-1.01-1.5-1.01-.31 0-.4.09-.4.52v1.35c0 .36-.12.58-1.06.58-1.56 0-3.29-.94-4.51-2.7-1.84-2.62-2.34-4.58-2.34-4.98 0-.22.09-.43.52-.43h1.31c.39 0 .54.18.69.6.74 2.14 1.98 4.01 2.49 4.01.19 0 .28-.09.28-.58v-2.25c-.06-.99-.58-1.08-.58-1.43 0-.18.15-.36.39-.36h2.06c.33 0 .45.18.45.57v3.04c0 .33.15.45.24.45.19 0 .35-.12.7-.47 1.08-1.21 1.85-3.08 1.85-3.08.1-.21.28-.43.72-.43h1.31c.47 0 .57.24.47.57-.15.81-1.91 3.47-1.91 3.47-.16.26-.22.37 0 .66.16.21.69.68 1.05 1.08.65.75 1.15 1.38 1.28 1.81.14.43-.07.65-.5.65z"/>
                      </svg>
                      VK
                    </a>
                  );
                }
                
                if (userProfile.social_telegram) {
                  socialLinks.push(
                    <a
                      key="telegram"
                      href={userProfile.social_telegram.startsWith('http') ? userProfile.social_telegram : `https://t.me/${userProfile.social_telegram.replace('@', '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 bg-[#0088CC] rounded-lg text-white hover:opacity-80 transition-opacity"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/>
                      </svg>
                      Telegram
                    </a>
                  );
                }
                
                if (userProfile.social_instagram) {
                  socialLinks.push(
                    <a
                      key="instagram"
                      href={userProfile.social_instagram}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 bg-gradient-to-br from-[#833AB4] via-[#FD1D1D] to-[#F77737] rounded-lg text-white hover:opacity-80 transition-opacity"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                      </svg>
                      Instagram
                    </a>
                  );
                }
                
                if (userProfile.social_facebook) {
                  socialLinks.push(
                    <a
                      key="facebook"
                      href={userProfile.social_facebook}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 bg-[#1877F2] rounded-lg text-white hover:opacity-80 transition-opacity"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                      </svg>
                      Facebook
                    </a>
                  );
                }
                
                if (userProfile.social_linkedin) {
                  socialLinks.push(
                    <a
                      key="linkedin"
                      href={userProfile.social_linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 bg-[#0A66C2] rounded-lg text-white hover:opacity-80 transition-opacity"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
                      </svg>
                      LinkedIn
                    </a>
                  );
                }
                
                if (userProfile.social_youtube) {
                  socialLinks.push(
                    <a
                      key="youtube"
                      href={userProfile.social_youtube}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 bg-[#FF0000] rounded-lg text-white hover:opacity-80 transition-opacity"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                      </svg>
                      YouTube
                    </a>
                  );
                }
                
                if (userProfile.social_website) {
                  socialLinks.push(
                    <a
                      key="website"
                      href={userProfile.social_website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 px-4 py-2 bg-[#6B7280] rounded-lg text-white hover:opacity-80 transition-opacity"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                      </svg>
                      Веб-сайт
                    </a>
                  );
                }
                
                // Показываем секцию только если есть хотя бы одна социальная сеть
                return socialLinks.length > 0 ? (
                  <div>
                    <h2 className="text-xl font-semibold text-white mb-3">Социални мрежи</h2>
                    <div className="flex flex-wrap gap-3">
                      {socialLinks}
                    </div>
                  </div>
                ) : null;
              })()}
            </div>

            {/* Посты пользователя */}
            <div className="bg-[#1A1826] rounded-lg p-6 sm:p-8">
              <h2 className="text-2xl font-bold text-white mb-6">Публикации на автора</h2>
              
              {isLoadingPosts ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="bg-[#2A2A2A] rounded-lg overflow-hidden animate-pulse">
                      <div className="w-full h-48 bg-gray-600"></div>
                      <div className="p-4">
                        <div className="h-3 bg-gray-600 rounded w-1/4 mb-2"></div>
                        <div className="h-5 bg-gray-600 rounded w-3/4 mb-2"></div>
                        <div className="h-4 bg-gray-600 rounded w-full mb-1"></div>
                        <div className="h-4 bg-gray-600 rounded w-2/3 mb-4"></div>
                        <div className="flex justify-between">
                          <div className="h-3 bg-gray-600 rounded w-1/4"></div>
                          <div className="h-3 bg-gray-600 rounded w-1/3"></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : userPosts.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {userPosts.map((post) => (
                    <div
                      key={post.id}
                      onClick={() => router.push(`/posts/${post.id}`)}
                      className="bg-[#2A2A2A] rounded-lg overflow-hidden cursor-pointer hover:bg-[#333333] transition-colors"
                    >
                      {post.preview_image_link && (
                        <img
                          src={post.preview_image_link}
                          alt={post.title}
                          className="w-full h-48 object-cover"
                        />
                      )}
                      <div className="p-4">
                        <div className="text-xs text-[#8A63D2] mb-2">
                          {post.category_display}
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 line-clamp-2">
                          {post.title}
                        </h3>
                        <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                          {post.preview_text}
                        </p>
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>{formatDate(post.created_at)}</span>
                          <div className="flex items-center gap-3">
                            <span>⭐ {parseFloat(post.rating).toFixed(1)}</span>
                            <span>💬 {post.comments_count}</span>
                            <span>👁 {post.views_count}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-400 text-lg">
                    Този потребител все още няма публикации
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
