'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { getStoredTokens, getUserData } from '@/lib/api';
import { setPageTitle } from '@/lib/setPageTitle';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import UserProfileView from '@/components/UserProfileView';

export default function UserProfilePage() {
  const router = useRouter();
  const params = useParams();
  const userId = params.userId as string;
  const [currentUser, setCurrentUser] = useState<any>(null);

  useEffect(() => {
    setPageTitle('Профиль пользователя');
    const { accessToken } = getStoredTokens();
    if (!accessToken) {
      router.push('/signIn');
      return;
    }
    
    const user = getUserData();
    setCurrentUser(user);
  }, [router]);

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: '#090F1B' }}>
      <Header activePage="" />
      
      <main className="flex-1 max-w-[1920px] w-full mx-auto px-4 sm:px-6 lg:px-[50px] py-6 sm:py-8 lg:py-12">
        <UserProfileView userId={userId} currentUserId={currentUser?.id} />
      </main>

      <Footer />
    </div>
  );
}
